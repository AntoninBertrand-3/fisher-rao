"""Compare full Gaussian MDM with covariance-only and mean-only MDM on saved trials."""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys
from time import perf_counter

import numpy as np
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from fisher_rao.spd_mean import covariance_distance, covariance_mean
from fisher_rao.triangles import TriangleObjective, triangle_center
from compare_mdm_sampled import json_default


def evaluate_components(train: dict, test: dict) -> dict:
    """Fit and evaluate separate covariance-only and mean-only classifiers.

    Parameters
    ----------
    train, test : dict
        Gaussian means, covariances and labels for independent balanced splits.

    Returns
    -------
    dict
        Prototypes, distances, predictions, fit diagnostics and timings by method.
        Nonconverged covariance fits are flagged, with last-iterate scores retained.
    """
    train = {key: np.asarray(train[key]) for key in ('means', 'covariances', 'labels')}
    test = {key: np.asarray(test[key]) for key in ('means', 'covariances', 'labels')}
    results = {}
    for method in ('covariance_only', 'mean_only'):
        start = perf_counter()
        prototypes, diagnostics = [], []
        for label in (0, 1):
            selected = train['labels'] == label
            if method == 'covariance_only':
                fit = covariance_mean(train['covariances'][selected])
                prototypes.append(fit.pop('matrix'))
                diagnostics.append(fit)
            else:
                prototypes.append(train['means'][selected].mean(axis=0))
                diagnostics.append(dict(converged=True))
        train_seconds = perf_counter() - start
        start = perf_counter()
        if method == 'mean_only':
            distances = np.linalg.norm(test['means'][:, None] - np.array(prototypes)[None], axis=2)
        else:
            distances = np.array([[covariance_distance(prototype, matrix) for prototype in prototypes]
                                  for matrix in test['covariances']])
        predictions = np.argmin(distances, axis=1)
        predict_seconds = perf_counter() - start
        confusion = np.zeros((2, 2), dtype=int)
        np.add.at(confusion, (test['labels'], predictions), 1)
        results[method] = dict(prototypes=prototypes, fit_details=diagnostics,
                               distances=distances, predictions=predictions, confusion=confusion,
                               accuracy=float(np.mean(predictions == test['labels'])),
                               all_fits_converged=all(fit['converged'] for fit in diagnostics),
                               prediction_coverage=1., train_seconds=train_seconds,
                               predict_seconds=predict_seconds)
    return results


def evaluate_triangles(train: dict, test: dict) -> dict:
    """Fit each directed triangle classifier on training data and predict held-out labels.

    Parameters
    ----------
    train, test : dict
        Means, SPD covariances and class labels on the fixed shared splits.

    Returns
    -------
    dict
        Squared divergences, prototypes, predictions, timings and fit diagnostics.
        Failed fits/predictions remain explicit and count as classification errors.
    """
    results = {}
    means, covariances = np.asarray(train['means']), np.asarray(train['covariances'])
    labels, targets = np.asarray(train['labels']), np.asarray(test['labels'])
    for kind in ('c', 'perp'):
        start = perf_counter()
        prototypes, diagnostics = [], []
        for label in (0, 1):
            try:
                selected = labels == label
                fit = triangle_center(means[selected], covariances[selected], kind=kind)
                prototypes.append((fit.pop('mean'), fit.pop('covariance')))
                diagnostics.append(fit)
            except (ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                prototypes.append(None)
                diagnostics.append(dict(converged=False, error=str(error)))
        train_seconds = perf_counter() - start
        start = perf_counter()
        objective = TriangleObjective(test['means'], test['covariances'], kind)
        divergences = np.full((len(targets), 2), np.nan)
        prediction_errors = []
        for label, prototype in enumerate(prototypes):
            if prototype is not None:
                try:
                    divergences[:, label] = objective.evaluate(*prototype)[0]
                except (ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                    prediction_errors.append(dict(label=label, error=str(error)))
        qualified = np.isfinite(divergences).all(axis=1)
        predictions = np.full(len(targets), -1)
        predictions[qualified] = np.argmin(divergences[qualified], axis=1)
        predict_seconds = perf_counter() - start
        confusion = np.zeros((2, 3), dtype=int)
        np.add.at(confusion, (targets, np.where(predictions < 0, 2, predictions)), 1)
        results[f'triangle_{kind}'] = dict(prototypes=prototypes, fit_details=diagnostics,
            squared_divergences=divergences, predictions=predictions, confusion=confusion,
            accuracy=float(np.mean(predictions == targets)),
            all_fits_converged=all(fit['converged'] for fit in diagnostics),
            prediction_coverage=float(qualified.mean()), prediction_errors=prediction_errors,
            train_seconds=train_seconds, predict_seconds=predict_seconds)
    return results


def main() -> None:
    """Reuse saved Fisher results and write a paired four-method component comparison."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=ROOT / 'results/mdm_sampled_3d.json')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--triangles', action='store_true', help='Also fit both published triangle centers.')
    args = parser.parse_args()
    raw = args.input.read_bytes()
    source = json.loads(raw)
    dimension = source['metadata']['dimension']
    if args.output is None:
        name = 'mdm_triangles' if args.triangles else 'mdm_components'
        args.output = ROOT / 'results' / f'{name}_{dimension}d'
    rows, records = [], []
    methods = ('fisher', 'd0', 'covariance_only', 'mean_only')
    if args.triangles:
        methods += ('triangle_c', 'triangle_perp')
    with threadpool_limits(limits=1):
        for trial in source['trials']:
            results = {method: trial['methods'][method] for method in ('fisher', 'd0')}
            results.update(evaluate_components(trial['train'], trial['test']))
            if args.triangles:
                results.update(evaluate_triangles(trial['train'], trial['test']))
            identity = {key: trial[key] for key in ('family', 'scenario', 'separation', 'batch_size', 'seed')}
            records.append(dict(**identity, methods=results))
            for method, result in results.items():
                rows.append(dict(**identity, method=method,
                                 **{key: result[key] for key in ('accuracy', 'all_fits_converged',
                                    'prediction_coverage', 'train_seconds', 'predict_seconds')}))
    metadata = dict(source=str(args.input), source_sha256=hashlib.sha256(raw).hexdigest(),
                    source_metadata=source['metadata'], blas_threads=1,
                    covariance_distance='sqrt(sum(log(generalized_eigenvalues)**2)); trace metric',
                    covariance_mean_options=dict(tol=1e-8, maxiter=200, init='arithmetic'),
                    mean_distance='Euclidean norm; arithmetic class prototype',
                    fisher_d0='Saved predictions and shared Fisher prototypes; timings from source run')
    if args.triangles:
        metadata['triangles'] = dict(source='https://doi.org/10.1109/ICASSP43922.2022.9747872',
            formulas='Corollaries 1 and 2 as printed', orientation='center first, observation second',
            objective='mean(squared divergence)/2; equation 18', optimizer='SciPy BFGS, analytic gradients',
            parameterization='mean and log-diagonal Cholesky in arithmetic-whitened coordinates',
            starts='arithmetic covariance, first training covariance; both at arithmetic mean',
            gtol=1e-7, optimizer_gtol=1e-8, maxiter=500, global_optimality='not certified')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.with_suffix('.json').write_text(
        json.dumps(dict(metadata=metadata, trials=records), default=json_default, indent=2) + '\n', encoding='utf-8')
    with args.output.with_suffix('.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = [f'# {dimension}D Gaussian MDM comparison', '',
             f"Saved source trials: {len(records)}; source status: "
             f"{source['metadata'].get('run_status', 'see source metadata')}. "
             'Only saved trials are evaluated; seed counts are explicit in the table.', '',
             'Paired synthetic observations. Fisher/d0 results reused from the saved source; '
             'new prototypes use only the same training splits. d0 shares the Fisher prototype; '
             'covariance-only uses its SPD Frechet mean; mean-only uses its arithmetic mean.', '',
             'Covariance distance uses the trace metric. Multiplying it by 1/sqrt(2) to match '
             'the covariance Fisher normalization changes neither prototypes nor predictions.', '',
             '| Scenario | Separation | Batch | Seeds | ' + ' | '.join(method+' %' for method in methods) + ' | Covariance fits converged |',
             '|---|---:|---:|---:|' + '---:|' * (len(methods)+1)]
    for family in dict.fromkeys(row['family'] for row in rows):
        selected = [row for row in rows if row['family'] == family]
        first = selected[0]
        cells = []
        for method in methods:
            values = np.array([100 * row['accuracy'] for row in selected if row['method'] == method])
            cells.append(f'{values.mean():.2f} +/- {values.std(ddof=1 if len(values)>1 else 0):.2f}')
        converged = sum(row['all_fits_converged'] for row in selected if row['method'] == 'covariance_only')
        lines.append(f"| {first['scenario']} | {first['separation']} | {first['batch_size'] or 'exact'} | "
                     f"{len(selected)//len(methods)} | " + ' | '.join(cells) + f' | {converged}/{len(selected)//len(methods)} |')
    lines += ['', 'Variability is SD across seeds, not a confidence interval. '
              'Fisher distances retain the source minimizing-geodesic assumption. '
              'No universal superiority claim; these are complete pipeline comparisons.', '',
              f"Converged method/trial fits: {sum(row['all_fits_converged'] for row in rows)}/{len(rows)}.",
              '', 'Reproduce: `python experiments/compare_mdm_components.py' + (' --triangles' if args.triangles else '')
              + f' --input "{args.input}" --output "{args.output}"`.']
    lines += ['', '## Unresolved strict covariance-mean stopping checks', '',
              'Last-iterate scores are retained without filtering. The tolerance is 1e-8 '
              'on the whitened mean-log norm; Armijo descent can stall near floating-point '
              'objective resolution. No tolerance was relaxed.']
    for record in records:
        for label, fit in enumerate(record['methods']['covariance_only']['fit_details']):
            if not fit['converged']:
                lines.append(f"- {record['family']}, seed {record['seed']}, class {label}: "
                             f"gradient norm {fit['gradient_norm']:.4g}, iterations {fit['iterations']}.")
    if args.triangles:
        lines += ['', '## Triangle center qualification', '',
                  'Each triangle has its own fitted center, minimizing equation (18). '
                  'Both training and prediction put the center first. Formulas are the published '
                  'squared divergences, without symmetrization. BFGS uses log-Cholesky coordinates '
                  'and analytic gradients rather than the paper\'s retraction algorithm. '
                  'Two deterministic starts do not certify global optimality.', '']
        for method in ('triangle_c', 'triangle_perp'):
            fits = [fit for record in records for fit in record['methods'][method]['fit_details']]
            lines.append(f"- {method}: {sum(fit['converged'] for fit in fits)}/{len(fits)} centers qualified.")
            for record in records:
                for label, fit in enumerate(record['methods'][method]['fit_details']):
                    if not fit['converged']:
                        lines.append(f"  - {record['family']}, seed {record['seed']}, class {label}: "
                                     + (str(fit['runs'][fit['selected_start']]) if 'runs' in fit else fit['error']))
    args.output.with_suffix('.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
