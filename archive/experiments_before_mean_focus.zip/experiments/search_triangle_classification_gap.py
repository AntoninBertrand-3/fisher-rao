"""Find fixed 3D test laws whose nearest prototype changes between dF and delta_c."""

import csv
import json
from pathlib import Path
import sys

import numpy as np
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from fisher_rao import d_f_reference
from fisher_rao.triangles import triangle_divergence_squared
from compare_mdm_sampled import json_default


def make_candidate(seed: int) -> tuple[np.ndarray, np.ndarray]:
    """Generate a deterministic anisotropic 3D Gaussian candidate.

    Parameters
    ----------
    seed : int
        NumPy seed controlling the candidate orientation and log-spectrum.

    Returns
    -------
    mean, covariance : ndarray
        SPD Gaussian parameters with moderate-to-extreme anisotropy.
    """
    rng = np.random.default_rng(seed)
    basis, triangular = np.linalg.qr(rng.normal(size=(3, 3)))
    basis *= np.where(np.diag(triangular) < 0, -1., 1.)
    log_spectrum = rng.uniform(-3.5, 3.5, size=3)
    covariance = (basis * np.exp(log_spectrum)) @ basis.T
    mean = rng.normal(size=3) * rng.uniform(.5, 5.)
    return mean, (covariance + covariance.T)/2


def main() -> None:
    """Evaluate a fixed candidate list and retain all nearest-prototype disagreements."""
    identity = (np.zeros(3), np.eye(3))
    stress = (np.array([1., 10., 0.]), np.diag([.01, 100., 1.]))
    mixed = (np.array([1., 1., 1.]), np.diag([.25, 1., 4.]))
    anisotropic = (np.array([1., 3., 1.]), np.diag([.1, 1., 10.]))
    prototype_pairs = [('identity_stress', identity, stress),
                       ('mixed_anisotropic', mixed, anisotropic),
                       ('identity_anisotropic', identity, anisotropic)]
    rows = []
    with threadpool_limits(limits=1):
        for pair_name, first, second in prototype_pairs:
            for seed in range(100, 115):
                target = make_candidate(seed)
                fisher, triangle = [], []
                for prototype in (first, second):
                    result = d_f_reference(*prototype, *target, n_starts=2, seed=20261019,
                                           gtol=2e-5, maxiter=1000)
                    fisher.append(result.distance)
                    triangle.append(np.sqrt(triangle_divergence_squared(*prototype, *target, kind='c')))
                row = dict(pair=pair_name, seed=seed, fisher_0=fisher[0], fisher_1=fisher[1],
                           triangle_0=triangle[0], triangle_1=triangle[1],
                           fisher_choice=int(np.argmin(fisher)), triangle_choice=int(np.argmin(triangle)),
                           mean_json=json.dumps(target[0].tolist()), covariance_json=json.dumps(target[1].tolist()),
                           fisher_reliable=True)
                if row['fisher_choice'] != row['triangle_choice']:
                    rows.append(row)
                    print(f"{pair_name} seed={seed}: Fisher {fisher} -> {row['fisher_choice']}; "
                          f"delta_c {triangle} -> {row['triangle_choice']}", flush=True)
    output = ROOT / 'results' / 'triangle_classification_gap'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.with_suffix('.json').write_text(json.dumps(dict(
        prototypes=dict(identity=identity, stress=stress, mixed=mixed, anisotropic=anisotropic), candidates_tested=45,
        search='three fixed prototype pairs, seeds 100..114; retain only nearest-prototype disagreements',
        rows=rows), default=json_default, indent=2)+'\n', encoding='utf-8')
    with output.with_suffix('.csv').open('w', newline='', encoding='utf-8') as stream:
        fields = list(rows[0]) if rows else ['seed', 'fisher_choice', 'triangle_choice']
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader(); writer.writerows(rows)
    print(f'Found {len(rows)} disagreements among 25 fixed candidates.')


if __name__ == '__main__':
    main()
