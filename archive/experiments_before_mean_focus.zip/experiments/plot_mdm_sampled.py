"""Plot baseline and hierarchical MDM results without recomputing distances."""

import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    """Plot scenario accuracies versus batch size, including the exact-law control."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=Path(__file__).resolve().parents[1] / 'results' / 'mdm_sampled_3d.csv')
    args = parser.parse_args()
    with args.input.open(newline='', encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    dimension = int(rows[0].get('dimension', 3))
    separations = sorted({float(row['separation']) for row in rows})
    scenarios = list(dict.fromkeys(row['scenario'] for row in rows))
    fig, axes = plt.subplots(len(scenarios), len(separations), figsize=(12, 10), sharey=True, squeeze=False, layout='constrained')
    panels = [(scenario, separation, axes[i, j]) for i, scenario in enumerate(scenarios)
              for j, separation in enumerate(separations)]
    for scenario, separation, axis in panels:
        selected = [row for row in rows if row['scenario'] == scenario and float(row['separation']) == separation]
        sizes = sorted({int(row['batch_size'] or 0) for row in selected})
        for method, color, label in [('naive', '#56718f', 'Arithmetic + Euclidean'),
                                      ('fisher', '#c56a26', 'Fisher prototypes + numerical dF'),
                                      ('d0', '#238443', 'Same Fisher prototypes + d0'),
                                      ('euclidean_fisher', '#9467bd', 'Same Fisher prototypes + Euclidean')]:
            values = [np.array([100 * float(row['accuracy']) for row in selected
                                 if row['method'] == method and int(row['batch_size'] or 0) == size]) for size in sizes]
            axis.errorbar(sizes, [value.mean() for value in values],
                           yerr=[value.std(ddof=1) if len(value) > 1 else 0 for value in values],
                           marker='o', color=color, label=label, capsize=4)
            for size, value in zip(sizes, values):
                axis.scatter(size * np.exp(np.linspace(-.035, .035, len(value))), value,
                              color=color, s=12, alpha=.65)
        axis.set_xticks(sizes, [str(size) if size else 'Exact laws' for size in sizes])
        axis.set_xlabel(f'Raw {dimension}D vectors per fitted MVN' if sizes != [0] else 'No sampling noise')
        axis.set_title(f'{scenario.replace("_", " ")} | s={separation}')
        axis.axhline(50, color='#999999', linestyle=':', linewidth=1)
        axis.grid(alpha=.2)
        axis.spines[['top', 'right']].set_visible(False)
        axis.set_ylim(0, 103)
        axis.set_ylabel('Held-out accuracy (%)')
    axes[0, 0].set_ylabel('Held-out accuracy (%)')
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='outside lower center', ncol=2, fontsize=9)
    fig.suptitle(f'MDM on {dimension}D Gaussian laws: fixed-parent and hierarchical generators\n'
                  'Dots: seeds. Error bars: SD across seeds, not confidence intervals.', fontsize=12)
    for suffix in ('.png', '.svg'):
        fig.savefig(args.input.with_suffix(suffix), dpi=180)
    plt.close(fig)


if __name__ == '__main__':
    main()
