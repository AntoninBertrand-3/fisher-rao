"""Compare MDM pipelines and shared-prototype distances on Gaussian laws.

Run: python experiments/compare_mdm_sampled.py
Includes the classifier fitting, qualification and reporting helpers.
"""

import argparse
import csv
import json
from pathlib import Path
import platform
import sys
from time import perf_counter

import numpy as np
import scipy
from scipy.linalg import expm
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from fisher_rao import d_0, d_f_reference, frechet_mean_mvn, log_map_mvn

LOG_OPTIONS = dict(n_starts=2, seed=1701, gtol=1e-11, maxiter=2000,
                   residual_tol=1e-8, endpoint_tol=1e-7)
METHODS = ('naive', 'fisher', 'd0', 'euclidean_fisher')


def distance_record(base: tuple, target: tuple) -> dict:
    """Compute a qualified numerical Fisher length and retain solver diagnostics.

    Parameters
    ----------
    base, target : tuple
        Gaussian parameters (mean, covariance).

    Returns
    -------
    dict
        Candidate distance, qualification, spectral checks and restart diagnostics.
        Failed solves are retained with a null distance.
    """
    try:
        result = log_map_mvn(*base, *target, **LOG_OPTIONS)
        return dict(distance=result.distance, reliable=result.reliable,
                    diagnostics=result.diagnostics, parameters=result.parameters,
                    runs=[dict(success=bool(run.success), message=str(run.message),
                               nit=int(run.get('nit', 0)), nfev=int(run.get('nfev', 0)),
                               diagnostics=run.get('diagnostics'),
                               qualification_error=run.get('qualification_error')) for run in result.runs])
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
        return dict(distance=None, reliable=False, error=str(error))


def evaluate_trial(family: str, seed: int, train: dict, test: dict) -> dict:
    """Fit two prototype sets and compare four classifiers on the same test data.

    Parameters
    ----------
    family : str
        Fixed generator and batch-size identifier.
    seed : int
        Replicate identifier.
    train, test : dict
        Independent splits, each with means, covariances and balanced labels.

    Returns
    -------
    dict
        Endpoints, prototypes, predictions, confusion matrices, timings and checks.
        Unqualified test predictions count as errors rather than being dropped.
    """
    fits, summaries = {}, {}
    for method in METHODS:
        start = perf_counter()
        prototypes, fit_details = [], []
        shared = method in ('d0', 'euclidean_fisher')
        if shared:
            prototypes = fits['fisher']['prototypes']
            fit_details = fits['fisher']['fit_details']
        for label in (() if shared else range(2)):
            selected = train['labels'] == label
            means, covariances = train['means'][selected], train['covariances'][selected]
            initial = (means.mean(axis=0), covariances.mean(axis=0))
            if method == 'naive':
                prototypes.append(initial)
                fit_details.append(dict(converged=True))
            else:
                try:
                    result = frechet_mean_mvn(means, covariances, init=initial,
                                              max_iter=60, tol=1e-6, log_options=LOG_OPTIONS)
                    prototypes.append((result.mean, result.covariance))
                    fit_details.append(dict(converged=result.converged, message=result.message,
                                            history=result.history))
                except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                    prototypes.append(None)
                    fit_details.append(dict(converged=False, error=str(error)))
        train_seconds = fits['fisher']['train_seconds'] if shared else perf_counter() - start
        start = perf_counter()
        distances = np.full((len(test['labels']), 2), np.nan)
        qualified = np.zeros_like(distances, dtype=bool)
        records = []
        for index, target in enumerate(zip(test['means'], test['covariances'])):
            row = []
            for label, prototype in enumerate(prototypes):
                if prototype is None:
                    row.append(dict(reliable=False, error='Prototype fit failed.'))
                elif method in ('naive', 'euclidean_fisher'):
                    distances[index, label] = np.sqrt(np.sum((target[0] - prototype[0])**2)
                                                       + np.sum((target[1] - prototype[1])**2))
                    qualified[index, label] = True
                elif method == 'd0':
                    try:
                        distances[index, label] = d_0(*prototype, *target)
                        qualified[index, label] = np.isfinite(distances[index, label])
                        row.append(dict(reliable=bool(qualified[index, label])))
                    except (ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                        row.append(dict(reliable=False, error=str(error)))
                else:
                    record = distance_record(prototype, target)
                    row.append(record)
                    if record['distance'] is not None:
                        distances[index, label] = record['distance']
                    qualified[index, label] = record['reliable']
            if row:
                records.append(row)
        predict_seconds = perf_counter() - start
        valid = qualified.all(axis=1)
        predictions = np.full(len(valid), -1)
        predictions[valid] = np.argmin(distances[valid], axis=1)
        confusion = np.zeros((2, 3), dtype=int)
        np.add.at(confusion, (test['labels'], np.where(predictions == -1, 2, predictions)), 1)
        summary = dict(accuracy=float(np.mean(predictions == test['labels'])),
                       prediction_coverage=float(valid.mean()),
                       all_fits_converged=all(item['converged'] for item in fit_details),
                       train_seconds=train_seconds, predict_seconds=predict_seconds,
                       confusion=confusion)
        summaries[method] = summary
        fits[method] = dict(prototypes=prototypes, fit_details=fit_details,
                            predictions=predictions, distances=distances, distance_records=records,
                            qualified_distances=qualified,
                            prototype_method='arithmetic' if method == 'naive' else 'fisher',
                            training_reused=shared, **summary)
    # Independently check one test-to-prototype distance per class using reduced J.
    validation = []
    for label, prototype in enumerate(fits['fisher']['prototypes']):
        if prototype is not None:
            index = int(np.flatnonzero(test['labels'] == label)[0])
            target = (test['means'][index], test['covariances'][index])
            try:
                reference = d_f_reference(*prototype, *target, n_starts=3, gtol=1e-6)
                validation.append(dict(reference_reliable=reference.reliable,
                                       difference=abs(reference.distance - fits['fisher']['distances'][index, label])))
            except (ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                validation.append(dict(reference_reliable=False, error=str(error)))
    return dict(family=family, seed=seed, train=train, test=test, methods=fits,
                independent_distance_checks=validation,
                shared_comparison=compare_shared_predictions(fits),
                accuracy_difference=summaries['fisher']['accuracy'] - summaries['naive']['accuracy'])


def compare_shared_predictions(fits: dict) -> dict:
    """Compare predictions and distances only where both methods are qualified.

    Parameters
    ----------
    fits : dict
        Results for methods sharing the identical fitted Fisher prototypes.

    Returns
    -------
    dict
        Disagreement counts with explicit denominators and d0 distance errors.
        Nonconverged prototypes exclude the trial from paired summaries.
    """
    reference = fits['fisher']
    result = {}
    for method in ('d0', 'euclidean_fisher'):
        candidate = fits[method]
        valid = ((reference['predictions'] >= 0) & (candidate['predictions'] >= 0)
                 & reference['all_fits_converged'])
        result[method] = dict(
            paired_count=int(valid.sum()),
            disagreements=int(np.sum(reference['predictions'][valid] != candidate['predictions'][valid])))
    valid = (reference['qualified_distances'] & fits['d0']['qualified_distances']
             & reference['all_fits_converged'])
    absolute = np.abs(fits['d0']['distances'][valid] - reference['distances'][valid])
    nonzero = reference['distances'][valid] > 1e-7
    relative = absolute[nonzero] / reference['distances'][valid][nonzero]
    result['d0'].update(distance_count=int(valid.sum()), relative_count=int(nonzero.sum()),
                        maximum_absolute_error=float(absolute.max()) if absolute.size else None,
                        maximum_relative_error=float(relative.max()) if relative.size else None)
    return result


def json_default(value: object) -> object:
    """Convert NumPy values for durable JSON output.

    Parameters
    ----------
    value : object
        NumPy array or scalar encountered by the JSON encoder.

    Returns
    -------
    object
        Native list or scalar.

    Raises
    ------
    TypeError
        If the value has an unsupported type.
    """
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(str(type(value)))





def parent_gaussians(separation: float, dimension: int = 3) -> tuple[np.ndarray, np.ndarray]:
    """Construct two fixed parents differing in mean and covariance.

    Parameters
    ----------
    separation : float
        Positive parameter controlling both parent differences.
    dimension : int
        Feature dimension, at least three. Three preserves the original parents.

    Returns
    -------
    means, covariances : ndarray, shapes (2,n), (2,n,n)
        First parent (0,C0), second (s*v,Q exp(s*B) Q), Q=sqrt(C0).
    """
    if dimension < 3:
        raise ValueError('Parent dimension must be at least three.')
    C0 = np.diag(np.resize([1., .6, 1.8], dimension))
    Q = np.diag(np.sqrt(np.diag(C0)))
    B = np.array([[.7, .35, -.2], [.35, -.6, .25], [-.2, .25, .2]])
    direction = np.array([.8, -.5, .6])
    if dimension != 3:
        # A fixed dense symmetric perturbation excites every feature direction.
        rng = np.random.default_rng(20261019)
        raw = rng.standard_normal((dimension, dimension))
        symmetric = (raw + raw.T) / 2
        B = symmetric * (np.linalg.norm(B) / np.linalg.norm(symmetric))
        extended = np.resize(direction, dimension)
        direction = extended * (np.linalg.norm(direction) / np.linalg.norm(extended))
    C1 = Q @ expm(separation * B) @ Q
    means = np.array([np.zeros(dimension), separation * direction])
    return means, np.array([C0, (C1 + C1.T) / 2])


def estimate_descriptors(batches: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Fit sample means and unbiased covariances to independent observation batches.

    Parameters
    ----------
    batches : ndarray, shape (k,m,n)
        k independent raw observation batches, each with m>n vectors.

    Returns
    -------
    means, covariances : ndarray, shapes (k,n), (k,n,n)
        Sample means and symmetric sample covariances using denominator m-1.

    Raises
    ------
    ValueError
        If shape, batch size, finiteness or numerical positive definiteness fails.
    """
    batches = np.asarray(batches, dtype=float)
    if batches.ndim != 3 or batches.shape[2] < 1 or batches.shape[1] <= batches.shape[2] or batches.shape[0] == 0:
        raise ValueError('Expected a nonempty (k,m,n) batch with m>n.')
    if not np.isfinite(batches).all():
        raise ValueError('Raw observations must be finite.')
    means = batches.mean(axis=1)
    centered = batches - means[:, None, :]
    covariances = centered.transpose(0, 2, 1) @ centered / (batches.shape[1] - 1)
    if np.any(np.linalg.eigvalsh(covariances) <= 0):
        raise ValueError('A sample covariance is not numerically positive definite; no regularization applied.')
    return means, covariances


def generate_sample(separation: float, batch_size: int, count: int, seed: int, dimension: int = 3) -> dict:
    """Draw independent Gaussian batches and fit one MVN descriptor per batch.

    Parameters
    ----------
    separation : float
        Parent separation parameter, passed to parent_gaussians.
    batch_size : int
        Number of raw vectors per descriptor, greater than dimension.
    count : int
        Descriptor count per class.
    seed : int
        Local NumPy random generator seed, different between training and test.
    dimension : int
        Feature dimension, at least three.

    Returns
    -------
    dict
        Fitted means, covariances and balanced labels. Batches do not overlap.
    """
    rng = np.random.default_rng(seed)
    parent_means, parent_covariances = parent_gaussians(separation, dimension)
    factors = np.linalg.cholesky(parent_covariances)
    # Shape: class, descriptor, raw observation, feature.
    normal = rng.standard_normal((2, count, batch_size, dimension))
    batches = normal @ factors[:, None].transpose(0, 1, 3, 2) + parent_means[:, None, None, :]
    means, covariances = estimate_descriptors(batches.reshape(2 * count, batch_size, dimension))
    return dict(means=means, covariances=covariances, labels=np.repeat([0, 1], count))


def generate_hierarchical_sample(
    separation: float, batch_size: int | None, count: int, seed: int,
    mean_spread: float = .35, covariance_spread: float = .35,
    dimension: int = 3,
) -> dict:
    """Generate varying Gaussian laws and optionally estimate them from batches.

    Parameters
    ----------
    separation : float
        Class-centre separation, as in parent_gaussians.
    batch_size : int or None
        Raw vectors per descriptor (>dimension), or None to observe the latent laws.
    count : int
        Positive number of descriptors per class.
    seed : int
        Seed for independent latent and observation random streams.
    mean_spread, covariance_spread : float
        Finite nonnegative tau values in mu=mu_c+tau_mu*L*z and
        Sigma=L*exp(tau_Sigma*H)*L.T, where L is the centre Cholesky factor,
        z~N(0,I), H=(G+G.T)/sqrt(2*n), and G has iid N(0,1) entries.
    dimension : int
        Feature dimension n, at least three.

    Returns
    -------
    dict
        Descriptors, labels, exact latent parameters and child-stream seeds.
        Latent laws are identical across batch sizes for a fixed seed.

    Raises
    ------
    ValueError
        If counts or spreads are invalid or a covariance is not SPD.
    """
    if count < 1 or (batch_size is not None and batch_size <= dimension):
        raise ValueError('Require count>0 and batch_size>dimension or None.')
    if not np.isfinite([mean_spread, covariance_spread]).all() or min(mean_spread, covariance_spread) < 0:
        raise ValueError('Spreads must be finite and nonnegative.')
    latent_seed, observation_seed = np.random.SeedSequence(seed).spawn(2)
    latent_rng = np.random.default_rng(latent_seed)
    observation_rng = np.random.default_rng(observation_seed)
    centers, center_covariances = parent_gaussians(separation, dimension)
    factors = np.linalg.cholesky(center_covariances)[:, None]
    z = latent_rng.standard_normal((2, count, dimension))
    raw = latent_rng.standard_normal((2, count, dimension, dimension))
    symmetric = (raw + raw.swapaxes(-1, -2)) / np.sqrt(2 * dimension)
    values, vectors = np.linalg.eigh(symmetric)
    exponentials = (vectors * np.exp(covariance_spread * values)[..., None, :]) @ vectors.swapaxes(-1, -2)
    latent_means = centers[:, None] + mean_spread * (factors @ z[..., None])[..., 0]
    latent_covariances = factors @ exponentials @ factors.swapaxes(-1, -2)
    latent_means = latent_means.reshape(2 * count, dimension)
    latent_covariances = latent_covariances.reshape(2 * count, dimension, dimension)
    if np.any(np.linalg.eigvalsh(latent_covariances) <= 0):
        raise ValueError('Latent covariance is not numerically SPD.')
    if batch_size is None:
        means, covariances = latent_means.copy(), latent_covariances.copy()
    else:
        normal = observation_rng.standard_normal((2 * count, batch_size, dimension))
        roots = np.linalg.cholesky(latent_covariances)
        batches = normal @ roots.swapaxes(-1, -2) + latent_means[:, None]
        means, covariances = estimate_descriptors(batches)
    return dict(means=means, covariances=covariances, labels=np.repeat([0, 1], count),
                latent_means=latent_means, latent_covariances=latent_covariances,
                latent_spawn_key=latent_seed.spawn_key, observation_spawn_key=observation_seed.spawn_key)


def save_report(records: list[dict], metadata: dict, output: Path) -> None:
    """Save the complete design, paired comparisons and unfiltered trial results.

    Parameters
    ----------
    records : list of dict
        Trials including latent laws, fitted descriptors and numerical failures.
    metadata : dict
        Generator definitions, seeds and solver settings.
    output : Path
        Prefix for JSON, CSV and Markdown reports.
    """
    output.parent.mkdir(parents=True, exist_ok=True)
    output.with_suffix('.json').write_text(
        json.dumps(dict(metadata=metadata, trials=records), default=json_default, indent=2) + '\n',
        encoding='utf-8')
    rows = []
    for record in records:
        for method, result in record['methods'].items():
            paired = record['shared_comparison'].get(method, {})
            rows.append(dict(
                dimension=metadata['dimension'], family=record['family'], scenario=record['scenario'], separation=record['separation'],
                batch_size=record['batch_size'], seed=record['seed'], method=method,
                prototype_method=result['prototype_method'], training_reused=result['training_reused'],
                **{key: result[key] for key in ('accuracy', 'prediction_coverage', 'all_fits_converged',
                                               'train_seconds', 'predict_seconds')},
                paired_count=paired.get('paired_count'), disagreements=paired.get('disagreements'),
                maximum_relative_error=paired.get('maximum_relative_error')))
    with output.with_suffix('.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = [f"# {metadata['dimension']}D Gaussian-law MDM comparison", '',
             'Numerical observations on a fixed synthetic design; no universal performance claim.', '',
             'Design and generator equations: [docs/mdm_benchmark.md](../docs/mdm_benchmark.md).', '',
             f"{metadata['repeats']} seeds; {metadata['train_per_class']} training and "
             f"{metadata['test_per_class']} test laws per class. Spreads are fixed before evaluation: "
             f"tau_mu={metadata['mean_spread']}, tau_Sigma={metadata['covariance_spread']}.", '',
             'Baseline: small batches from one parent per class. Hierarchical: a different latent law '
             'per observation, observed directly (exact) or estimated from a small batch (sampled). '
             'No shrinkage, seed selection, test tuning or failure filtering.', '',
             'Naive uses arithmetic prototypes with Euclidean parameter distance. Fisher, d0 and '
             'Euclidean/shared use exactly the same estimated Fisher prototypes. '
             'd0 is a prediction approximation, not a separately optimized d0 Frechet mean.', '',
             '| Scenario | s | Batch | Naive % | Fisher % | d0/shared % | Euclidean/shared % | Qualified Fisher trials |',
             '|---|---:|---:|---:|---:|---:|---:|---:|']
    for family in dict.fromkeys(record['family'] for record in records):
        subset = [record for record in records if record['family'] == family]
        first = subset[0]
        cells = []
        for method in METHODS:
            values = 100 * np.array([record['methods'][method]['accuracy'] for record in subset])
            cells.append(f"{values.mean():.2f} +/- {values.std(ddof=1 if len(values)>1 else 0):.2f}")
        qualified = sum(record['methods']['fisher']['all_fits_converged'] and
                        record['methods']['fisher']['prediction_coverage'] == 1 for record in subset)
        lines.append(f"| {first['scenario']} | {first['separation']} | {first['batch_size'] or 'exact'} | "
                     + ' | '.join(cells) + f' | {qualified}/{len(subset)} |')
    lines += ['', 'Variability is SD across seeds, not a confidence interval. Unqualified predictions '
              'are -1 and count as classification errors. Nonconverged prototype fits are flagged; '
              'their last-iterate accuracies remain visible in the table.', '',
              '## Paired distance comparison on shared Fisher prototypes', '',
              '| Family | d0 disagreements / qualified predictions | Max d0 relative distance error | Fisher prediction seconds | d0 prediction seconds |',
              '|---|---:|---:|---:|---:|']
    for family in dict.fromkeys(record['family'] for record in records):
        subset = [record for record in records if record['family'] == family]
        paired = [record['shared_comparison']['d0'] for record in subset]
        errors = [item['maximum_relative_error'] for item in paired if item['maximum_relative_error'] is not None]
        maximum = f'{max(errors):.4%}' if errors else 'unqualified'
        fisher_time = sum(record['methods']['fisher']['predict_seconds'] for record in subset)
        d0_time = sum(record['methods']['d0']['predict_seconds'] for record in subset)
        lines.append(f"| {family} | {sum(p['disagreements'] for p in paired)}/{sum(p['paired_count'] for p in paired)} | "
                     f'{maximum} | {fisher_time:.4f} | {d0_time:.4f} |')
    lines += ['', 'Paired summaries require converged prototypes and qualified predictions for both '
              'methods; denominators are explicit. Distance relative errors additionally require '
              'd_F > 1e-7. Per-pair distances and qualification masks are in JSON. '
              'Timings use one BLAS thread. Shared methods reuse the Fisher fit; their reported '
              'training cost is that same fit cost, not another fit or a zero-cost prototype.', '',
              '## Qualification', '',
              'Fisher lengths use qualified horizontal solves with spectral, residual and endpoint '
              'checks, under the existing minimizing-geodesic assumption. Independent reduced-J '
              'checks use three starts. Neither checks nor optimizer success certify global minima.', '']
    checks = [check for record in records for check in record['independent_distance_checks']]
    differences = [check['difference'] for check in checks
                   if check.get('reference_reliable') and np.isfinite(check.get('difference', np.nan))]
    lines.append(f'- Reduced-J spot checks qualified and finite: {len(differences)}/{len(checks)}; '
                 f'maximum discrepancy {max(differences, default=float("nan")):.3g}.')
    for record in records:
        fisher = record['methods']['fisher']
        if not fisher['all_fits_converged'] or fisher['prediction_coverage'] != 1:
            lines.append(f"- {record['family']}, seed {record['seed']}: fits converged="
                         f"{fisher['all_fits_converged']}, prediction coverage={fisher['prediction_coverage']:.3f}.")
    lines += ['', 'Reproduce:', '', '```powershell',
              f"python experiments/compare_mdm_sampled.py --dimension {metadata['dimension']} "
              f"--batch-sizes {' '.join(map(str, metadata['raw_batch_sizes']))} "
              f"--repeats {metadata['repeats']} --train {metadata['train_per_class']} "
              f"--test {metadata['test_per_class']} --mean-spread {metadata['mean_spread']} "
              f"--covariance-spread {metadata['covariance_spread']} --output \"{output}\"",
              f'python experiments/plot_mdm_sampled.py --input "{output.with_suffix(".csv")}"', '```']
    output.with_suffix('.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def main() -> None:
    """Run the fixed baseline and hierarchical scenarios with saved diagnostics."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dimension', type=int, default=3)
    parser.add_argument('--batch-sizes', type=int, nargs='+')
    parser.add_argument('--repeats', type=int, default=5)
    parser.add_argument('--train', type=int, default=12)
    parser.add_argument('--test', type=int, default=40)
    parser.add_argument('--mean-spread', type=float, default=.35)
    parser.add_argument('--covariance-spread', type=float, default=.35)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if args.dimension < 3:
        parser.error('Dimension must be at least three.')
    if args.batch_sizes is None:
        args.batch_sizes = [5, 10, 20] if args.dimension == 3 else [15, 30, 60]
    if any(size <= args.dimension for size in args.batch_sizes):
        parser.error('Every batch size must exceed dimension (unregularized covariance).')
    if args.output is None:
        args.output = ROOT / 'results' / f'mdm_sampled_{args.dimension}d'
    if min(args.repeats, args.train, args.test) < 1:
        parser.error('Counts must be positive.')
    if not np.isfinite([args.mean_spread, args.covariance_spread]).all() or min(args.mean_spread, args.covariance_spread) < 0:
        parser.error('Spreads must be finite and nonnegative.')
    metadata = dict(repeats=args.repeats, train_per_class=args.train, test_per_class=args.test,
                    python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
                    log_options=LOG_OPTIONS, mean_options=dict(max_iter=60, tol=1e-6, init='arithmetic'),
                    seeds=[20261016 + 100 * index for index in range(args.repeats)],
                    parents={str(s): dict(zip(('means', 'covariances'), parent_gaussians(s, args.dimension))) for s in (.35, .8)},
                    mean_spread=args.mean_spread, covariance_spread=args.covariance_spread,
                    hierarchy='mu=mu_c+tau_mu*L*z; C=L*exp(tau_C*H)*L.T; L=chol(C_c); '
                              'z iid N(0,1); H=(G+G.T)/sqrt(2*n); G iid N(0,1)',
                    random_streams='SeedSequence(seed).spawn(2): latent, observations',
                    raw_batch_sizes=args.batch_sizes, dimension=args.dimension, covariance_ddof=1, regularization=None,
                    parent_construction='original at n=3; otherwise dense symmetric seed=20261019, '
                                        'original Frobenius B norm and mean direction norm; cyclic C0 diagonal',
                    split_seeds='train=replicate seed, test=replicate seed+1', blas_threads=1,
                    shared_prototypes='fisher, d0, euclidean_fisher',
                    reference_definition='qualified horizontal geodesic length; assumed minimizing',
                    relative_distance_threshold=1e-7)
    records = []
    start = perf_counter()
    scenarios = [('baseline', size) for size in metadata['raw_batch_sizes']]
    scenarios += [('hierarchical_sampled', size) for size in metadata['raw_batch_sizes']]
    scenarios += [('hierarchical_exact', None)]
    with threadpool_limits(limits=1):
        for scenario, batch_size in scenarios:
            for separation in (.35, .8):
                family = f'{scenario}_s{separation}_m{batch_size or "exact"}'
                for seed in metadata['seeds']:
                    print(f'{family} seed={seed}: fitting and classifying', flush=True)
                    splits = []
                    for count, split_seed in ((args.train, seed), (args.test, seed + 1)):
                        if scenario == 'baseline':
                            sample = generate_sample(separation, batch_size, count, split_seed, args.dimension)
                        else:
                            sample = generate_hierarchical_sample(
                                separation, batch_size, count, split_seed,
                                args.mean_spread, args.covariance_spread, args.dimension)
                        splits.append(sample)
                    record = evaluate_trial(family, seed, *splits)
                    record.update(scenario=scenario, separation=separation, batch_size=batch_size)
                    records.append(record)
                    save_report(records, metadata, args.output)
                    print('  ' + ' '.join(f"{method}={data['accuracy']:.3f} "
                                          f"fit_ok={data['all_fits_converged']} coverage={data['prediction_coverage']:.3f}"
                                          for method, data in record['methods'].items()), flush=True)
    print(f'Finished {len(records)} trials in {perf_counter()-start:.1f} seconds.', flush=True)


if __name__ == '__main__':
    main()
