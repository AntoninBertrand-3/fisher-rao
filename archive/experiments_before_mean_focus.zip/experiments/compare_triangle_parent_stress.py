"""Compare Fisher/d0 with the two triangle divergences on a fixed 3D parent pair."""

import csv
import json
from pathlib import Path
import sys
from time import perf_counter

import numpy as np
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from compare_mdm_sampled import evaluate_trial, estimate_descriptors, json_default
from compare_mdm_components import evaluate_triangles


def stress_parents() -> tuple[np.ndarray, np.ndarray]:
    """Return the fixed 3D parent pair with a large dF/delta_c discrepancy.

    Returns
    -------
    means, covariances : ndarray, shapes (2,3), (2,3,3)
        Parent A=N(0,I) and parent B=N((1,10,0),diag(.01,100,1)).
    """
    return np.array([[0., 0., 0.], [1., 10., 0.]]), np.array([
        np.eye(3), np.diag([.01, 100., 1.])])


def sample_parents(batch_size: int | None, count: int, seed: int) -> dict:
    """Generate independent descriptors from the fixed stress parents.

    Parameters
    ----------
    batch_size : int or None
        Raw vectors per descriptor, or None for exact parent-law descriptors.
    count : int
        Number of descriptors per class.
    seed : int
        NumPy seed for independent class batches.

    Returns
    -------
    dict
        Means, unbiased sample covariances, labels and parent metadata.
    """
    if batch_size is not None and batch_size <= 3:
        raise ValueError('Batch size must exceed dimension three.')
    parent_means, parent_covariances = stress_parents()
    if batch_size is None:
        means = np.repeat(parent_means, count, axis=0)
        covariances = np.repeat(parent_covariances, count, axis=0)
    else:
        rng = np.random.default_rng(seed)
        factors = np.linalg.cholesky(parent_covariances)
        normal = rng.standard_normal((2, count, batch_size, 3))
        batches = normal @ factors[:, None].transpose(0, 1, 3, 2) + parent_means[:, None, None]
        means, covariances = estimate_descriptors(batches.reshape(2*count, batch_size, 3))
    return dict(means=means, covariances=covariances, labels=np.repeat([0, 1], count),
                parent_means=parent_means, parent_covariances=parent_covariances)


def main() -> None:
    """Run the parent-stress MDM benchmark and save every trial and diagnostic."""
    seeds = [20261016 + 100*i for i in range(5)]
    scenarios = [(5, 'm5'), (10, 'm10'), (20, 'm20'), (None, 'exact')]
    records = []
    with threadpool_limits(limits=1):
        for batch_size, suffix in scenarios:
            for seed in seeds:
                train = sample_parents(batch_size, 12, seed)
                test = sample_parents(batch_size, 40, seed+1)
                start = perf_counter()
                base = evaluate_trial(f'parent_stress_{suffix}', seed, train, test)
                triangles = evaluate_triangles(train, test)
                base['methods'].update(triangles)
                base.update(scenario='parent_stress', batch_size=batch_size)
                records.append(base)
                print(f'{suffix} seed={seed}: Fisher={base["methods"]["fisher"]["accuracy"]:.3f} '
                      f'c={triangles["triangle_c"]["accuracy"]:.3f} '
                      f'perp={triangles["triangle_perp"]["accuracy"]:.3f} '
                      f'time={perf_counter()-start:.1f}s', flush=True)
    output = ROOT / 'results' / 'mdm_parent_stress_3d'
    metadata = dict(dimension=3, parent_means=stress_parents()[0], parent_covariances=stress_parents()[1],
                    parent_pair='N(0,I) versus N((1,10,0),diag(.01,100,1))',
                    seeds=seeds, train_per_class=12, test_per_class=40,
                    batch_sizes=[5,10,20], exact_control=True,
                    design='Fixed parent laws; only finite-batch descriptor estimation varies',
                    divergence_direction='center first, observation second',
                    reference='Qualified numerical dF under existing minimizing-geodesic assumption')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.with_suffix('.json').write_text(json.dumps(dict(metadata=metadata, trials=records),
        default=json_default, indent=2)+'\n', encoding='utf-8')
    methods = ('naive','fisher','d0','triangle_c','triangle_perp')
    rows=[]
    for record in records:
        for method in methods:
            result=record['methods'][method]
            rows.append(dict(batch_size=record['batch_size'] or 'exact', seed=record['seed'], method=method,
                             accuracy=result['accuracy'], all_fits_converged=result['all_fits_converged'],
                             prediction_coverage=result['prediction_coverage'],
                             train_seconds=result['train_seconds'], predict_seconds=result['predict_seconds']))
    with output.with_suffix('.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    lines=['# Parent-stress MDM: dF versus triangle divergences','',
           'Fixed parent pair: A=N(0,I3), B=N((1,10,0),diag(.01,100,1)). '
           'This pair has dF=5.413124 and forward delta_c=7.251064 on the parent endpoints. '
           'Classes are generated from these parents; no test law is selected by a classifier disagreement.','',
           '| Batch | Fisher % | d0 % | delta_c % | delta_perp % |', '|---:|---:|---:|---:|---:|']
    for batch_size, suffix in scenarios:
        subset=[r for r in rows if r['batch_size']==(batch_size or 'exact')]
        vals=[]
        for method in ('fisher','d0','triangle_c','triangle_perp'):
            values=np.array([100*r['accuracy'] for r in subset if r['method']==method])
            vals.append(f'{values.mean():.2f} +/- {values.std(ddof=1):.2f}')
        lines.append('| '+str(batch_size or 'exact')+' | '+' | '.join(vals)+' |')
    lines += ['', 'All five seeds use the same parent laws. SD is across seeds, not a confidence interval.',
              'Triangle centers are fitted independently for each method. Raw diagnostics and all predictions are in JSON.',
              'Reproduce: `python experiments/compare_triangle_parent_stress.py`.']
    output.with_suffix('.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines))


if __name__=='__main__':
    main()
