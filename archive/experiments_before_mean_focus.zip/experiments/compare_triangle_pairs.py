"""Compare directed triangle values with d0 and qualified numerical dF on eight fixed 3D pairs."""

import csv
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from threadpoolctl import threadpool_limits

from compare_mdm_sampled import LOG_OPTIONS, distance_record, json_default, parent_gaussians
from fisher_rao import d_0, d_f_reference
from fisher_rao.triangles import triangle_divergence_squared


def generate_pairs() -> list[dict]:
    """Construct fixed exact, mixed, anisotropic and MDM-parent examples without searching.

    Returns
    -------
    list of dict
        Named endpoint pairs, with optional independent exact Fisher distance.
    """
    specifications = [
        ('identical', [0., 0., 0.], [1., 1., 1.], 0.),
        ('equal_means', [0., 0., 0.], [.25, 1., 4.], np.log(4.)),
        ('mean_only', [2., 0., 0.], [1., 1., 1.], 2*np.sqrt(2)*np.arcsinh(2/np.sqrt(8))),
        ('isotropic', [1., 1., 1.], [2., 2., 2.], None),
        ('mixed_diagonal', [1., 1., 1.], [.25, 1., 4.], None),
        ('anisotropic', [1., 3., 1.], [.1, 1., 10.], None),
        ('stress_L100', [1., 10., 0.], [.01, 100., 1.], None),
    ]
    pairs = [dict(name=name, first=(np.zeros(3), np.eye(3)),
                  second=(np.array(mean), np.diag(diagonal)), exact=exact)
             for name, mean, diagonal, exact in specifications]
    means, covariances = parent_gaussians(.8)
    pairs.append(dict(name='mdm_parents_s0.8', first=(means[0], covariances[0]),
                      second=(means[1], covariances[1]), exact=None))
    return pairs


def evaluate_pair(pair: dict) -> dict:
    """Evaluate both orientations and cross-check the reference and affine invariance.

    Parameters
    ----------
    pair : dict
        Named explicit endpoints and optional exact Fisher distance.

    Returns
    -------
    dict
        Values and squared values, signed discrepancies, timings and diagnostics.
        Unqualified reference values remain visible with an explicit flag.
    """
    first, second = pair['first'], pair['second']
    start = perf_counter()
    forward, reverse = distance_record(first, second), distance_record(second, first)
    reference = d_f_reference(*first, *second, n_starts=5, seed=20261019, gtol=1e-6, maxiter=2000)
    reference_seconds = perf_counter()-start
    df = reference.distance
    discrepancies = [abs(record['distance']-df) if record['distance'] is not None else np.inf
                     for record in (forward, reverse)]
    exact_error = None if pair['exact'] is None else abs(df-pair['exact'])
    qualified = bool(reference.reliable and forward['reliable'] and reverse['reliable']
                     and max(discrepancies) < 1e-7 and (exact_error is None or exact_error < 1e-7))
    values, squared, times = {}, {}, {}
    for direction, endpoints in [('forward', (first, second)), ('reverse', (second, first))]:
        base, target = endpoints
        for method in ('d0', 'c', 'perp'):
            start = perf_counter()
            value_squared = (d_0(*base, *target)**2 if method == 'd0' else
                             triangle_divergence_squared(*base, *target, kind=method))
            key = f'{method}_{direction}'
            squared[key] = value_squared
            values[key] = float(np.sqrt(value_squared))
            times[key] = perf_counter()-start
    transform = np.array([[1.2, .3, -.2], [.1, .8, .4], [-.2, .1, 1.5]])
    shift = np.array([1., -2., .5])
    transformed = [(transform@mu+shift, transform@covariance@transform.T) for mu, covariance in (first, second)]
    invariance_errors = {}
    for method in ('d0', 'c', 'perp'):
        value = (d_0(*transformed[0], *transformed[1]) if method == 'd0' else
                 np.sqrt(triangle_divergence_squared(*transformed[0], *transformed[1], kind=method)))
        invariance_errors[method] = abs(value-values[f'{method}_forward'])
    return dict(**pair, d_f=df, d_f_squared=df**2, reference_qualified=qualified,
                reference_seconds=reference_seconds, values=values, squared_values=squared,
                signed_relative_discrepancies={key: value/df-1 if qualified and df>1e-7 else None
                                               for key, value in values.items()},
                timings=times, horizontal_forward=forward, horizontal_reverse=reverse,
                reduced_reliable=reference.reliable, reduced_message=reference.reliability_message,
                reduced_runs=[dict(success=bool(run.success), message=str(run.message),
                                   objective=float(run.fun), gradient_norm=float(np.linalg.norm(run.jac)),
                                   iterations=int(run.nit)) for run in reference.runs],
                independent_discrepancies=discrepancies, exact_error=exact_error,
                affine_transform=transform, affine_shift=shift, affine_errors=invariance_errors)


def main() -> None:
    """Save the eight-pair comparison, explicit inputs and numerical qualifications."""
    with threadpool_limits(limits=1):
        records = [evaluate_pair(pair) for pair in generate_pairs()]
    output = Path(__file__).resolve().parents[1] / 'results/triangle_pairs_3d'
    output.parent.mkdir(parents=True, exist_ok=True)
    metadata = dict(dimension=3, selection='Eight fixed illustrative pairs, no error-based search',
                    log_options=LOG_OPTIONS, reduced_options=dict(n_starts=5, seed=20261019, gtol=1e-6, maxiter=2000),
                    blas_threads=1, relative_threshold=1e-7,
                    interpretation='Published squared divergences retained; roots displayed alongside distances',
                    reference='Numerical reduced minimum checked against forward/reverse horizontal solves; no global certificate')
    output.with_suffix('.json').write_text(json.dumps(dict(metadata=metadata, pairs=records),
        default=json_default, indent=2)+'\n', encoding='utf-8')
    rows = [dict(name=r['name'], d_f=r['d_f'], reference_qualified=r['reference_qualified'],
                 **r['values'], **{key+'_squared': value for key,value in r['squared_values'].items()},
                 **{key+'_relative_signed': value for key,value in r['signed_relative_discrepancies'].items()})
            for r in records]
    with output.with_suffix('.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = ['# Triangle divergence values versus d0 and numerical dF (3D)', '',
             'Eight fixed illustrative pairs, not a worst-case search. Roots of the published squared '
             'divergences are displayed on the distance scale. They are generally asymmetric and '
             'need not bound dF. Squared values, both orientations and signed relative discrepancies '
             'are retained in CSV/JSON.', '',
             '| Pair | dF | d0 forward | delta_c forward | delta_c reverse | delta_perp forward | delta_perp reverse | Qualified reference |',
             '|---|---:|---:|---:|---:|---:|---:|---|']
    for r in records:
        cells = [r['d_f']] + [r['values'][key] for key in ('d0_forward','c_forward','c_reverse','perp_forward','perp_reverse')]
        lines.append('| '+r['name']+' | '+' | '.join(f'{value:.6f}' for value in cells)+f" | {r['reference_qualified']} |")
    lines += ['', '## Explicit endpoints', '', 'The first seven pairs start at N(0,I_3).']
    for r in records:
        lines.append(f"- {r['name']}: first={json.dumps(r['first'], default=json_default)}; second={json.dumps(r['second'], default=json_default)}.")
    lines += ['', '## Numerical checks', '',
              f"Qualified references: {sum(r['reference_qualified'] for r in records)}/{len(records)}.",
              f"Maximum horizontal/reduced discrepancy: {max(max(r['independent_discrepancies']) for r in records):.3g}.",
              f"Maximum affine-invariance discrepancy (d0 and triangle roots): {max(max(r['affine_errors'].values()) for r in records):.3g}.",
              'Qualification is numerical under the existing minimizing-geodesic assumption; it is not a global proof.', '',
              'Reproduce: `python experiments/compare_triangle_pairs.py`.']
    output.with_suffix('.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print('\n'.join(lines[:14]))
    print('\n'.join(lines[-7:]))


if __name__ == '__main__':
    main()
