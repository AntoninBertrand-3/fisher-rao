"""Search a fixed small catalogue for moderate-condition parent pairs with dF/delta_c gaps."""

import csv
import json
from pathlib import Path
import sys

import numpy as np
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from fisher_rao import d_f_reference
from fisher_rao.triangles import triangle_divergence_squared
from compare_mdm_sampled import json_default


def make_pairs() -> list[dict]:
    """Construct a fixed catalogue of moderate anisotropic parent pairs.

    Returns
    -------
    list of dict
        Parent A=N(0,I) and random SPD parent B with condition at most 100.
    """
    pairs=[]
    for seed in range(300, 325):
        rng=np.random.default_rng(seed)
        basis, triangular=np.linalg.qr(rng.normal(size=(3,3)))
        basis*=np.where(np.diag(triangular)<0,-1.,1.)
        eigenvalues=np.exp(rng.uniform(-2.3,2.3,size=3))
        covariance=(basis*eigenvalues)@basis.T
        mean=rng.normal(size=3); mean*=rng.uniform(1.,8.)/np.linalg.norm(mean)
        pairs.append(dict(seed=seed, first=(np.zeros(3),np.eye(3)),
                          second=(mean,(covariance+covariance.T)/2),
                          condition=float(eigenvalues.max()/eigenvalues.min())))
    return pairs


def main() -> None:
    """Evaluate the fixed catalogue and rank absolute and relative triangle gaps."""
    rows=[]
    with threadpool_limits(limits=1):
        for pair in make_pairs():
            first,second=pair['first'],pair['second']
            result=d_f_reference(*first,*second,n_starts=3,seed=20261019,gtol=1e-5,maxiter=1500)
            d_f=float(result.distance)
            delta_c=float(np.sqrt(triangle_divergence_squared(*first,*second,kind='c')))
            delta_reverse=float(np.sqrt(triangle_divergence_squared(*second,*first,kind='c')))
            rows.append(dict(seed=pair['seed'],condition=pair['condition'],d_f=d_f,
                             delta_c=delta_c,delta_c_reverse=delta_reverse,
                             relative=delta_c/d_f-1,relative_reverse=delta_reverse/d_f-1,
                             reliable=bool(result.reliable),mean=pair['second'][0],
                             covariance=pair['second'][1]))
    rows.sort(key=lambda row: max(abs(row['relative']),abs(row['relative_reverse'])),reverse=True)
    output=ROOT/'results'/'parent_gap_search'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.with_suffix('.json').write_text(json.dumps(dict(catalogue_size=len(rows),rows=rows),default=json_default,indent=2)+'\n',encoding='utf-8')
    fields=['seed','condition','d_f','delta_c','delta_c_reverse','relative','relative_reverse','reliable']
    with output.with_suffix('.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields); writer.writeheader(); writer.writerows({key:row[key] for key in fields} for row in rows)
    lines=['# Moderate-condition parent gap search','','| seed | condition | dF | delta_c | delta_c reverse | relative | relative reverse | reliable |','|---:|---:|---:|---:|---:|---:|---:|---|']
    for row in rows:
        lines.append('| '+str(row['seed'])+' | '+' | '.join(f'{row[key]:.6f}' for key in ('condition','d_f','delta_c','delta_c_reverse','relative','relative_reverse'))+' | '+str(row['reliable'])+' |')
    output.with_suffix('.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines[:10]))


if __name__=='__main__':
    main()
