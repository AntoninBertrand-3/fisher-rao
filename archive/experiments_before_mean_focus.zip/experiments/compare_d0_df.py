"""Run 38 fixed 3D cases with `python experiments/compare_d0_df.py`.

No search or adaptive case selection is performed. The suite has 20
identity/isotropic cases and 18 anisotropic cases. In isotropic
spaces the stored eigenbasis is the coordinate basis, not a unique eigenbasis.
Only reliable references greater than ZERO_THRESHOLD enter relative summaries.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
import json
from pathlib import Path
import platform
import sys
from time import perf_counter

import numpy as np
from numpy.typing import NDArray
import scipy

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from fisher_rao import d_0, d_f_reference

ZERO_THRESHOLD = 1e-7
N_STARTS = 3
GTOL = 1e-8
MAXITER = 1000


@dataclass
class Case:
    """A normalized endpoint and its reproducible construction metadata."""

    case_id: str
    dimension: int
    covariance_family: str
    covariance_parameter: float
    mu_norm: float
    mu_orientation: str
    seed: int
    mu: NDArray[np.float64]
    covariance: NDArray[np.float64]
    eigenvalues: NDArray[np.float64]


def generate_cases() -> list[Case]:
    """Build a fixed balanced selection without a full Cartesian product.

    Returns
    -------
    list of Case
        38 three-dimensional endpoints; seeds control both QR rotations and random mean directions.
    """
    cases = []
    norms = (0., .5, 1., 3., 10.)
    families = [("identity", 1.), ("isotropic", .5), ("isotropic", 2.), ("isotropic", 10.)]
    families += [(family, kappa) for family in ("diagonal", "random_spd") for kappa in (2., 10., 100.)]
    # Preserve the original 3D suite's seeds and case selection (index 2).
    for dimension_index, dimension in ((2, 3),):
        orientations = ("min_eigenvector", "max_eigenvector", "random", "balanced_extremes") if dimension >= 2 else ("min_eigenvector", "max_eigenvector", "random")
        for family_index, (family, parameter) in enumerate(families):
            selected = range(5) if family_index < 4 else [(dimension_index + family_index + offset) % 5 for offset in range(3)]
            for slot, norm_index in enumerate(selected):
                seed = 20260906 + dimension_index * 1000 + family_index * 10 + slot
                generator = np.random.default_rng(seed)
                eigenvalues = np.full(dimension, parameter) if family_index < 4 else np.geomspace(1 / parameter, parameter, dimension)
                basis = np.eye(dimension)
                if family == "random_spd":
                    basis, triangular = np.linalg.qr(generator.standard_normal((dimension, dimension)))
                    basis = basis * np.where(np.diag(triangular) < 0, -1., 1.)
                covariance = (basis * eigenvalues) @ basis.T
                covariance = (covariance + covariance.T) / 2
                orientation = orientations[(dimension_index + family_index + slot) % len(orientations)]
                if orientation == "min_eigenvector":
                    direction = basis[:, 0]
                elif orientation == "max_eigenvector":
                    direction = basis[:, -1]
                elif orientation == "balanced_extremes":
                    direction = (basis[:, 0] + basis[:, -1]) / np.sqrt(2)
                else:
                    direction = generator.standard_normal(dimension)
                    direction /= np.linalg.norm(direction)
                norm = norms[norm_index]
                if norm == 0:
                    orientation = "zero"
                cases.append(Case(f"case_{len(cases) + 1:03d}", dimension, family, parameter,
                                  norm, orientation, seed, norm * direction, covariance, eigenvalues))
    return cases


def special_case_distance(case: Case) -> float | None:
    """Compute independently justified special cases in the canonical metric.

    Parameters
    ----------
    case : Case
        Normalized endpoint.

    Returns
    -------
    float or None
        Closed-form distance for n=1, zero mean, or identity covariance.

    Notes
    -----
    For n=1 the metric is twice the hyperbolic half-plane metric after
    y=sqrt(2)*sigma; use its stable atanh distance formula. For zero mean,
    the covariance metric has factor 1/2. For identity covariance a rotation
    reduces the mean displacement to one hyperbolic factor. These derivations
    are recorded in src/fisher_rao/README.md; no general diagonal formula is assumed.
    """
    if case.dimension == 1:
        variance = float(case.covariance[0, 0])
        sigma = np.sqrt(variance)
        difference = (variance - 1) / (sigma + 1)
        ratio = np.hypot(case.mu[0], np.sqrt(2) * difference) / np.hypot(case.mu[0], np.sqrt(2) * (sigma + 1))
        return float(2 * np.sqrt(2) * np.arctanh(ratio))
    if case.mu_norm == 0:
        return float(np.linalg.norm(np.log(case.eigenvalues)) / np.sqrt(2))
    if case.covariance_family == "identity":
        return float(2 * np.sqrt(2) * np.arcsinh(case.mu_norm / np.sqrt(8)))
    return None


def evaluate_case(case: Case) -> dict[str, object]:
    """Measure both distances, retain diagnostics and qualify relative statistics.

    Parameters
    ----------
    case : Case
        Fixed Gaussian pair with implicit first endpoint (0, I).

    Returns
    -------
    dict
        CSV row including endpoints, solver settings, timings and exact checks.
    """
    args = (np.zeros(case.dimension), np.eye(case.dimension), case.mu, case.covariance)
    start = perf_counter()
    approximation = d_0(*args)
    runtime_d0 = perf_counter() - start
    start = perf_counter()
    reference = d_f_reference(*args, n_starts=N_STARTS, seed=case.seed, gtol=GTOL, maxiter=MAXITER)
    runtime_df = perf_counter() - start
    exact = special_case_distance(case)
    exact_error = None if exact is None else abs(reference.distance - exact)
    exact_pass = None if exact is None else bool(np.isclose(reference.distance, exact, rtol=1e-8, atol=1e-7))
    reliable = reference.reliable and exact_pass is not False
    nonzero = reference.distance > ZERO_THRESHOLD
    absolute = abs(approximation - reference.distance)
    diagnostics = [dict(success=bool(run.success), status=int(run.status), message=str(run.message),
                        objective=float(run.fun), gradient_norm=float(np.linalg.norm(run.jac)),
                        nit=int(run.nit), nfev=int(run.nfev)) for run in reference.runs]
    return dict(case_id=case.case_id, dimension=case.dimension,
                covariance_family=case.covariance_family, covariance_parameter=case.covariance_parameter,
                condition_number=float(case.eigenvalues.max() / case.eigenvalues.min()),
                mu_norm=case.mu_norm, mu_orientation=case.mu_orientation, seed=case.seed,
                d_f_reference=reference.distance, d_0=approximation, absolute_error=absolute,
                relative_error=absolute / reference.distance if nonzero else None,
                relative_excess=approximation / reference.distance - 1 if nonzero else None,
                optimizer_success=any(run.success for run in reference.runs) if reference.runs else None,
                optimizer_reliable=reference.reliable, reference_reliable=reliable,
                reliability_message=reference.reliability_message,
                relative_stats_included=reliable and nonzero,
                runtime_d_f=runtime_df, runtime_d_0=runtime_d0,
                exact_distance=exact, exact_absolute_error=exact_error, exact_check_pass=exact_pass,
                mu_json=json.dumps(case.mu.tolist()), covariance_json=json.dumps(case.covariance.tolist()),
                eigenvalues_json=json.dumps(case.eigenvalues.tolist()),
                optimizer="BFGS", n_starts=N_STARTS, gtol=GTOL, maxiter=MAXITER,
                zero_threshold=ZERO_THRESHOLD, optimizer_diagnostics_json=json.dumps(diagnostics),
                python_version=platform.python_version(), numpy_version=np.__version__, scipy_version=scipy.__version__)


def print_summary(rows: list[dict[str, object]], output: Path) -> None:
    """Print qualified statistics and the two requested case rankings.

    Parameters
    ----------
    rows : list of dict
        Experiment results.
    output : Path
        Saved CSV path.
    """
    eligible = [row for row in rows if row["relative_stats_included"]]
    errors = np.array([row["relative_error"] for row in eligible], dtype=float)
    print(f"Cas : {len(rows)} ; references fiables : {sum(row['reference_reliable'] for row in rows)}")
    print(f"Statistiques relatives : {len(eligible)} cas fiables avec d_F > {ZERO_THRESHOLD:g}")
    if errors.size:
        print(f"Erreur relative mediane : {np.median(errors):.8%}")
        print(f"Erreur relative moyenne : {np.mean(errors):.8%}")
        print(f"Erreur relative maximale : {np.max(errors):.8%}")
    for title, descending in (("10 plus grandes erreurs relatives", True), ("10 plus petites erreurs relatives", False)):
        print(f"\n{title} (cas fiables non nuls ; ex aequo par case_id)")
        print("case_id    n famille      param  cond      norme orientation             erreur_relative")
        ordered = sorted(eligible, key=lambda row: (-1 if descending else 1) * row["relative_error"])
        for row in ordered[:10]:
            print(f"{row['case_id']:10} {row['dimension']:2} {row['covariance_family']:12} "
                  f"{row['covariance_parameter']:5g} {row['condition_number']:8g} {row['mu_norm']:5g} "
                  f"{row['mu_orientation']:23} {row['relative_error']:.8%}")
    checked = [row for row in rows if row["exact_check_pass"] is not None]
    print(f"\nCas exacts compatibles : {sum(row['exact_check_pass'] for row in checked)}/{len(checked)}")
    print(f"Temps moyen (tous les cas) : d_F={np.mean([r['runtime_d_f'] for r in rows]):.6f} s ; "
          f"d_0={np.mean([r['runtime_d_0'] for r in rows]):.6f} s")
    print(f"CSV : {output}")


def main() -> None:
    """Execute the fixed experiment, save every row, and print the summary."""
    output = ROOT / "results" / "d0_vs_df_3d.csv"
    output.parent.mkdir(exist_ok=True)
    rows = []
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = None
        for case in generate_cases():
            row = evaluate_case(case)
            if writer is None:
                writer = csv.DictWriter(stream, fieldnames=list(row))
                writer.writeheader()
            writer.writerow(row)
            stream.flush()
            rows.append(row)
    print_summary(rows, output)


if __name__ == "__main__":
    main()
