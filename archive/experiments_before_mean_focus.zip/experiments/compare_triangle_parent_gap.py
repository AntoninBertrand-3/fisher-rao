"""Compare Fisher/d0 and triangle MDM on a moderate-condition parent gap."""

import csv
import json
import argparse
from pathlib import Path
import sys
from time import perf_counter

import numpy as np
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from compare_mdm_sampled import evaluate_trial, estimate_descriptors, json_default
from compare_mdm_components import evaluate_triangles


def parent_pair(seed: int = 312) -> tuple[np.ndarray,np.ndarray]:
    """Return one fixed parent pair from the predeclared gap catalogue.

    Returns
    -------
    means, covariances : ndarray
        Parent A=N(0,I3) and parent B with a moderate condition-number covariance.
    """
    search = ROOT / 'results' / 'parent_gap_search.json'
    rows = json.loads(search.read_text(encoding='utf-8'))['rows']
    row = next(item for item in rows if item['seed'] == seed)
    return np.array([[0.,0.,0.], row['mean']], dtype=float), np.array([
        np.eye(3), row['covariance']], dtype=float)


def sample(batch_size: int|None,count: int,seed: int,parent_seed: int)->dict:
    """Generate independent descriptors from the fixed parent pair.

    Parameters
    ----------
    batch_size : int or None
        Raw observations per descriptor, or None for exact laws.
    count : int
        Descriptors per class.
    seed : int
        Local NumPy random seed.

    Returns
    -------
    dict
        Means, unbiased covariances and balanced labels.
    """
    means,covariances=parent_pair(parent_seed)
    if batch_size is None:
        fitted_means=np.repeat(means,count,axis=0); fitted_covariances=np.repeat(covariances,count,axis=0)
    else:
        rng=np.random.default_rng(seed); factors=np.linalg.cholesky(covariances)
        normal=rng.standard_normal((2,count,batch_size,3))
        batches=normal@factors[:,None].transpose(0,1,3,2)+means[:,None,None]
        fitted_means,fitted_covariances=estimate_descriptors(batches.reshape(2*count,batch_size,3))
    return dict(means=fitted_means,covariances=fitted_covariances,labels=np.repeat([0,1],count))


def main()->None:
    """Run five-seed exact and finite-batch parent MDM controls."""
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parent-seed',type=int,default=312,choices=[308,309,311,312,324])
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    seeds=[20261016+100*i for i in range(5)]; scenarios=[(5,'m5'),(10,'m10'),(20,'m20'),(None,'exact')]
    records=[]
    with threadpool_limits(limits=1):
        for batch_size,suffix in scenarios:
            for seed in seeds:
                start=perf_counter(); result=evaluate_trial('parent_gap_'+suffix,seed,sample(batch_size,12,seed,args.parent_seed),sample(batch_size,40,seed+1,args.parent_seed))
                result['methods'].update(evaluate_triangles(sample(batch_size,12,seed,args.parent_seed),sample(batch_size,40,seed+1,args.parent_seed)))
                result.update(batch_size=batch_size,scenario='parent_gap'); records.append(result)
                print(suffix,seed,[(m,round(result['methods'][m]['accuracy'],3),round(result['methods'][m]['prediction_coverage'],3)) for m in ('fisher','d0','triangle_c','triangle_perp')],f'{perf_counter()-start:.1f}s',flush=True)
    output=args.output or ROOT/f'results/mdm_parent_gap_{args.parent_seed}_3d'; output.parent.mkdir(parents=True,exist_ok=True)
    selected=next(row for row in json.loads((ROOT/'results/parent_gap_search.json').read_text())['rows'] if row['seed']==args.parent_seed)
    metadata=dict(dimension=3,parent_seed=args.parent_seed,parent_means=parent_pair(args.parent_seed)[0],parent_covariances=parent_pair(args.parent_seed)[1],condition_number=selected['condition'],
                  endpoint_distances=dict(d_f=selected['d_f'],delta_c=selected['delta_c'],delta_c_reverse=selected['delta_c_reverse']),
                  seeds=seeds,train_per_class=12,test_per_class=40,batch_sizes=[5,10,20],exact_control=True,
                  design='Fixed parents; only finite-batch estimation varies; no disagreement-based test selection')
    output.with_suffix('.json').write_text(json.dumps(dict(metadata=metadata,trials=records),default=json_default,indent=2)+'\n',encoding='utf-8')
    methods=('fisher','d0','triangle_c','triangle_perp'); rows=[]
    for trial in records:
        for method in methods:
            r=trial['methods'][method]; rows.append(dict(batch_size=trial['batch_size'] or 'exact',seed=trial['seed'],method=method,accuracy=r['accuracy'],coverage=r['prediction_coverage'],fit_converged=r['all_fits_converged']))
    with output.with_suffix('.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    relative_excess=100*(selected['delta_c']/selected['d_f']-1)
    lines=['# Moderate-gap parent MDM: dF versus triangle divergences','',
           f"Parent seed {args.parent_seed}; covariance condition number {selected['condition']:.2f}; endpoint delta_c/d_F excess {relative_excess:.1f}%. No test law is selected by disagreement.",'', '| Batch | Fisher % | d0 % | delta_c % | delta_perp % | Fisher coverage |','|---:|---:|---:|---:|---:|---:|']
    for batch_size,suffix in scenarios:
        subset=[r for r in rows if r['batch_size']==(batch_size or 'exact')]
        vals=[]
        for method in methods:
            v=np.array([100*r['accuracy'] for r in subset if r['method']==method]); vals.append(f'{v.mean():.2f} +/- {v.std(ddof=1):.2f}')
        coverage=np.mean([r['coverage'] for r in subset if r['method']=='fisher'])
        lines.append('| '+str(batch_size or 'exact')+' | '+' | '.join(vals)+f' | {coverage:.3f} |')
    lines += ['', 'SD across five seeds. Fisher coverage is reported separately; unqualified dF predictions count as errors in accuracy.', f'Reproduce: `python experiments/compare_triangle_parent_gap.py --parent-seed {args.parent_seed}`.']
    output.with_suffix('.md').write_text('\n'.join(lines)+'\n',encoding='utf-8'); print('\n'.join(lines))


if __name__=='__main__': main()
