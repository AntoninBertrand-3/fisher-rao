"""Probe dimension dependence of triangle, d0 and numerical Fisher distances."""

import csv
import json
from pathlib import Path
import sys
from time import perf_counter

import numpy as np
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from fisher_rao import d_0, d_f_reference
from fisher_rao.triangles import triangle_divergence_squared
from compare_mdm_sampled import json_default


def cases(dimension: int) -> list[dict]:
    """Construct controlled normalized endpoint families in one dimension.

    Parameters
    ----------
    dimension : int
        Dimension n, at least three.

    Returns
    -------
    list of dict
        Isotropic, balanced anisotropic and mean-mixed endpoint pairs.
    """
    if dimension < 3:
        raise ValueError('Dimension must be at least three.')
    index = np.arange(dimension)
    families = [
        ('isotropic_mean', np.full(dimension, 2.), np.ones(dimension)),
        ('balanced_anisotropic', np.geomspace(1/10, 10, dimension), np.ones(dimension)),
        ('mixed_mean_anisotropic', np.geomspace(1/100, 100, dimension),
         np.linspace(0.4, 2.0, dimension)),
        ('strong_mixed', np.geomspace(1/1000, 1000, dimension),
         np.sin(index + 0.7) * 2.0),
    ]
    return [dict(name=name, first=(np.zeros(dimension), np.eye(dimension)),
                 second=(mean, np.diag(eigenvalues)))
            for name, eigenvalues, mean in families]


def evaluate(pair: dict, dimension: int) -> dict:
    """Evaluate dF, d0 and both directed triangle roots for one pair.

    Parameters
    ----------
    pair : dict
        Named normalized endpoint pair.
    dimension : int
        Endpoint dimension.

    Returns
    -------
    dict
        Values, signed relative discrepancies, timings and qualification flags.
    """
    first, second = pair['first'], pair['second']
    start = perf_counter()
    reference = d_f_reference(*first, *second, n_starts=3, seed=20261019,
                               gtol=1e-5, maxiter=1500)
    d_f = float(reference.distance)
    d0 = float(d_0(*first, *second))
    values = dict(d_f=d_f, d0=d0,
                  delta_c=np.sqrt(triangle_divergence_squared(*first, *second, kind='c')),
                  delta_perp=np.sqrt(triangle_divergence_squared(*first, *second, kind='perp')),
                  delta_c_reverse=np.sqrt(triangle_divergence_squared(*second, *first, kind='c')),
                  delta_perp_reverse=np.sqrt(triangle_divergence_squared(*second, *first, kind='perp')))
    return dict(dimension=dimension, name=pair['name'], **values,
                reference_reliable=bool(reference.reliable),
                runtime=perf_counter()-start,
                relative={key: value/d_f-1 if d_f > 1e-10 else None
                          for key, value in values.items()},
                optimizer_message=reference.reliability_message,
                optimizer_runs=[dict(success=bool(run.success), objective=float(run.fun),
                                     gradient_norm=float(np.linalg.norm(run.jac)), nit=int(run.nit))
                                for run in reference.runs])


def main() -> None:
    """Run the fixed dimension probe and save every case without adaptive search."""
    rows = []
    with threadpool_limits(limits=1):
        for dimension in (3, 5, 10):
            for pair in cases(dimension):
                print(f'{dimension}D {pair["name"]}', flush=True)
                rows.append(evaluate(pair, dimension))
    output = ROOT / 'results' / 'triangle_dimension_probe'
    output.parent.mkdir(parents=True, exist_ok=True)
    metadata = dict(dimensions=[3, 5, 10], families=[row['name'] for row in rows[:4]],
                    selection='Fixed controlled families; no error-based search',
                    d_f_options=dict(n_starts=3, seed=20261019, gtol=1e-5, maxiter=1500),
                    interpretation='Roots shown; divergences are directed and not Fisher bounds')
    output.with_suffix('.json').write_text(json.dumps(dict(metadata=metadata, cases=rows),
        default=json_default, indent=2)+'\n', encoding='utf-8')
    fields = ['dimension', 'name', 'd_f', 'd0', 'delta_c', 'delta_perp',
              'delta_c_reverse', 'delta_perp_reverse', 'reference_reliable']
    with output.with_suffix('.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows({field: row[field] for field in fields} for row in rows)
    lines = ['# Dimension probe: triangle divergences versus d0 and dF', '',
             '| n | Family | dF | d0 | delta_c | delta_perp | delta_c reverse | delta_perp reverse |',
             '|---:|---|---:|---:|---:|---:|---:|---:|']
    for row in rows:
        lines.append('| '+str(row['dimension'])+' | '+row['name']+' | '
                     + ' | '.join(f'{row[key]:.6f}' for key in
                                   ('d_f','d0','delta_c','delta_perp','delta_c_reverse','delta_perp_reverse'))+' |')
    lines += ['', 'All cases are fixed in advance; this is a probe, not a worst-case search.',
              'Reference reliability and optimizer diagnostics are in JSON.']
    output.with_suffix('.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
