# Full Gaussian versus component-only MDM

Paired synthetic observations. Fisher/d0 results reused from the saved source; new prototypes use only the same training splits. d0 shares the Fisher prototype; covariance-only uses its SPD Frechet mean; mean-only uses its arithmetic mean.

Covariance distance uses the trace metric. Multiplying it by 1/sqrt(2) to match the covariance Fisher normalization changes neither prototypes nor predictions.

| Scenario | Separation | Batch | Seeds | Fisher % | d0 % | Covariance only % | Mean only % | Covariance fits converged |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | 0.35 | 5 | 5 | 59.25 +/- 1.68 | 59.50 +/- 2.09 | 49.75 +/- 2.40 | 61.25 +/- 8.57 | 4/5 |
| baseline | 0.8 | 5 | 5 | 78.75 +/- 4.33 | 78.75 +/- 4.33 | 58.50 +/- 2.24 | 77.75 +/- 6.15 | 4/5 |
| baseline | 0.35 | 10 | 5 | 75.50 +/- 9.21 | 75.50 +/- 9.21 | 58.25 +/- 5.56 | 72.25 +/- 8.12 | 5/5 |
| baseline | 0.8 | 10 | 5 | 95.50 +/- 3.60 | 95.50 +/- 3.60 | 81.00 +/- 2.71 | 89.25 +/- 4.01 | 5/5 |
| baseline | 0.35 | 20 | 5 | 83.25 +/- 5.05 | 83.25 +/- 5.05 | 71.75 +/- 4.01 | 79.25 +/- 2.09 | 5/5 |
| baseline | 0.8 | 20 | 5 | 99.75 +/- 0.56 | 99.75 +/- 0.56 | 90.75 +/- 2.59 | 96.25 +/- 2.34 | 5/5 |
| hierarchical_sampled | 0.35 | 5 | 5 | 54.00 +/- 6.70 | 54.00 +/- 6.09 | 50.75 +/- 6.35 | 58.25 +/- 4.89 | 3/5 |
| hierarchical_sampled | 0.8 | 5 | 5 | 78.00 +/- 1.90 | 78.00 +/- 2.09 | 57.00 +/- 9.63 | 73.75 +/- 2.93 | 4/5 |
| hierarchical_sampled | 0.35 | 10 | 5 | 64.50 +/- 2.59 | 64.50 +/- 2.59 | 59.00 +/- 6.98 | 64.25 +/- 6.29 | 5/5 |
| hierarchical_sampled | 0.8 | 10 | 5 | 86.50 +/- 4.09 | 86.50 +/- 4.09 | 76.50 +/- 4.71 | 78.00 +/- 6.99 | 5/5 |
| hierarchical_sampled | 0.35 | 20 | 5 | 71.50 +/- 2.71 | 71.25 +/- 2.65 | 63.25 +/- 7.32 | 68.25 +/- 6.77 | 5/5 |
| hierarchical_sampled | 0.8 | 20 | 5 | 92.50 +/- 0.88 | 92.50 +/- 0.88 | 84.25 +/- 3.81 | 81.00 +/- 6.75 | 5/5 |
| hierarchical_exact | 0.35 | exact | 5 | 74.25 +/- 3.26 | 74.25 +/- 3.26 | 72.25 +/- 6.27 | 67.75 +/- 6.52 | 5/5 |
| hierarchical_exact | 0.8 | exact | 5 | 96.25 +/- 1.25 | 96.25 +/- 1.25 | 93.00 +/- 2.59 | 86.75 +/- 3.81 | 5/5 |

Variability is SD across seeds, not a confidence interval. Fisher distances retain the source minimizing-geodesic assumption. No universal superiority claim; these are complete pipeline comparisons.

Converged method/trial fits: 275/280.

Reproduce: `python experiments/compare_mdm_components.py`.

## Unresolved strict covariance-mean stopping checks

Last-iterate scores are retained without filtering. The tolerance is 1e-8 on the whitened mean-log norm; Armijo descent can stall near floating-point objective resolution. No tolerance was relaxed.
- baseline_s0.35_m5, seed 20261116, class 0: gradient norm 1.524e-08, iterations 20.
- baseline_s0.8_m5, seed 20261116, class 0: gradient norm 1.524e-08, iterations 20.
- hierarchical_sampled_s0.35_m5, seed 20261016, class 1: gradient norm 1.978e-07, iterations 22.
- hierarchical_sampled_s0.35_m5, seed 20261316, class 0: gradient norm 1.163e-08, iterations 40.
- hierarchical_sampled_s0.8_m5, seed 20261316, class 0: gradient norm 1.163e-08, iterations 40.
