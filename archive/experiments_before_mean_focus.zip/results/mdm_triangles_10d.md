# 10D Gaussian MDM comparison

Saved source trials: 37; source status: stopped_at_user_request. Only saved trials are evaluated; seed counts are explicit in the table.

Paired synthetic observations. Fisher/d0 results reused from the saved source; new prototypes use only the same training splits. d0 shares the Fisher prototype; covariance-only uses its SPD Frechet mean; mean-only uses its arithmetic mean.

Covariance distance uses the trace metric. Multiplying it by 1/sqrt(2) to match the covariance Fisher normalization changes neither prototypes nor predictions.

| Scenario | Separation | Batch | Seeds | fisher % | d0 % | covariance_only % | mean_only % | triangle_c % | triangle_perp % | Covariance fits converged |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | 0.35 | 15 | 5 | 65.75 +/- 5.42 | 66.00 +/- 5.11 | 55.00 +/- 8.20 | 67.25 +/- 4.18 | 63.75 +/- 6.43 | 65.25 +/- 6.27 | 5/5 |
| baseline | 0.8 | 15 | 5 | 91.50 +/- 2.71 | 91.25 +/- 2.34 | 73.25 +/- 5.77 | 93.25 +/- 2.09 | 93.00 +/- 1.90 | 92.25 +/- 2.56 | 5/5 |
| baseline | 0.35 | 30 | 5 | 78.25 +/- 6.47 | 78.25 +/- 6.47 | 62.00 +/- 4.38 | 80.00 +/- 4.68 | 79.25 +/- 7.21 | 77.75 +/- 6.58 | 5/5 |
| baseline | 0.8 | 30 | 5 | 99.75 +/- 0.56 | 99.75 +/- 0.56 | 89.00 +/- 2.85 | 98.00 +/- 1.90 | 99.50 +/- 0.68 | 99.50 +/- 0.68 | 5/5 |
| baseline | 0.35 | 60 | 5 | 90.50 +/- 3.38 | 90.50 +/- 3.38 | 75.00 +/- 3.19 | 89.50 +/- 3.38 | 91.25 +/- 2.93 | 90.25 +/- 3.69 | 5/5 |
| baseline | 0.8 | 60 | 5 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 97.00 +/- 2.09 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 5/5 |
| hierarchical_sampled | 0.35 | 15 | 5 | 58.50 +/- 2.40 | 58.25 +/- 2.59 | 49.75 +/- 5.69 | 58.50 +/- 2.71 | 59.75 +/- 4.37 | 56.50 +/- 1.63 | 5/5 |
| hierarchical_sampled | 0.8 | 15 | 2 | 77.50 +/- 7.07 | 77.50 +/- 7.07 | 63.12 +/- 0.88 | 77.50 +/- 0.00 | 78.12 +/- 2.65 | 77.50 +/- 5.30 | 2/2 |

Variability is SD across seeds, not a confidence interval. Fisher distances retain the source minimizing-geodesic assumption. No universal superiority claim; these are complete pipeline comparisons.

Converged method/trial fits: 222/222.

Reproduce: `python experiments/compare_mdm_components.py --triangles --input "results\mdm_sampled_10d.json" --output "results\mdm_triangles_10d"`.

## Unresolved strict covariance-mean stopping checks

Last-iterate scores are retained without filtering. The tolerance is 1e-8 on the whitened mean-log norm; Armijo descent can stall near floating-point objective resolution. No tolerance was relaxed.

## Triangle center qualification

Each triangle has its own fitted center, minimizing equation (18). Both training and prediction put the center first. Formulas are the published squared divergences, without symmetrization. BFGS uses log-Cholesky coordinates and analytic gradients rather than the paper's retraction algorithm. Two deterministic starts do not certify global optimality.

- triangle_c: 74/74 centers qualified.
- triangle_perp: 74/74 centers qualified.
