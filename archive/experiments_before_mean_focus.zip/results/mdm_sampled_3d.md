# 3D Gaussian-law MDM comparison

Numerical observations on a fixed synthetic design; no universal performance claim.

Design and generator equations: [docs/mdm_benchmark.md](../docs/mdm_benchmark.md).

5 seeds; 12 training and 40 test laws per class. Spreads are fixed before evaluation: tau_mu=0.35, tau_Sigma=0.35.

Baseline: small batches from one parent per class. Hierarchical: a different latent law per observation, observed directly (exact) or estimated from a small batch (sampled). No shrinkage, seed selection, test tuning or failure filtering.

Naive uses arithmetic prototypes with Euclidean parameter distance. Fisher, d0 and Euclidean/shared use exactly the same estimated Fisher prototypes. d0 is a prediction approximation, not a separately optimized d0 Frechet mean.

| Scenario | s | Batch | Naive % | Fisher % | d0/shared % | Euclidean/shared % | Qualified Fisher trials |
|---|---:|---:|---:|---:|---:|---:|---:|
| baseline | 0.35 | 5 | 56.25 +/- 5.45 | 59.25 +/- 1.68 | 59.50 +/- 2.09 | 55.25 +/- 6.27 | 5/5 |
| baseline | 0.8 | 5 | 73.25 +/- 4.11 | 78.75 +/- 4.33 | 78.75 +/- 4.33 | 72.50 +/- 5.00 | 5/5 |
| baseline | 0.35 | 10 | 67.75 +/- 7.88 | 75.50 +/- 9.21 | 75.50 +/- 9.21 | 69.50 +/- 9.46 | 5/5 |
| baseline | 0.8 | 10 | 87.50 +/- 4.24 | 95.50 +/- 3.60 | 95.50 +/- 3.60 | 88.75 +/- 3.95 | 5/5 |
| baseline | 0.35 | 20 | 72.25 +/- 4.28 | 83.25 +/- 5.05 | 83.25 +/- 5.05 | 75.00 +/- 5.23 | 5/5 |
| baseline | 0.8 | 20 | 93.25 +/- 3.38 | 99.75 +/- 0.56 | 99.75 +/- 0.56 | 94.50 +/- 3.49 | 5/5 |
| hierarchical_sampled | 0.35 | 5 | 50.75 +/- 6.29 | 54.00 +/- 6.70 | 54.00 +/- 6.09 | 50.25 +/- 4.95 | 5/5 |
| hierarchical_sampled | 0.8 | 5 | 64.75 +/- 6.81 | 78.00 +/- 1.90 | 78.00 +/- 2.09 | 65.75 +/- 4.73 | 5/5 |
| hierarchical_sampled | 0.35 | 10 | 61.75 +/- 3.81 | 64.50 +/- 2.59 | 64.50 +/- 2.59 | 61.50 +/- 3.69 | 5/5 |
| hierarchical_sampled | 0.8 | 10 | 76.50 +/- 2.24 | 86.50 +/- 4.09 | 86.50 +/- 4.09 | 81.00 +/- 4.28 | 5/5 |
| hierarchical_sampled | 0.35 | 20 | 65.00 +/- 7.86 | 71.50 +/- 2.71 | 71.25 +/- 2.65 | 67.25 +/- 8.59 | 5/5 |
| hierarchical_sampled | 0.8 | 20 | 84.50 +/- 5.42 | 92.50 +/- 0.88 | 92.50 +/- 0.88 | 88.00 +/- 3.71 | 5/5 |
| hierarchical_exact | 0.35 | exact | 72.25 +/- 4.95 | 74.25 +/- 3.26 | 74.25 +/- 3.26 | 75.50 +/- 4.20 | 5/5 |
| hierarchical_exact | 0.8 | exact | 93.75 +/- 2.65 | 96.25 +/- 1.25 | 96.25 +/- 1.25 | 95.25 +/- 2.40 | 5/5 |

Variability is SD across seeds, not a confidence interval. Unqualified predictions are -1 and count as classification errors. Nonconverged prototype fits are flagged; their last-iterate accuracies remain visible in the table.

## Paired distance comparison on shared Fisher prototypes

| Family | d0 disagreements / qualified predictions | Max d0 relative distance error | Fisher prediction seconds | d0 prediction seconds |
|---|---:|---:|---:|---:|
| baseline_s0.35_m5 | 1/400 | 2.0459% | 5.7487 | 0.2760 |
| baseline_s0.8_m5 | 0/400 | 2.3452% | 5.9182 | 0.2813 |
| baseline_s0.35_m10 | 0/400 | 0.3541% | 5.4300 | 0.2902 |
| baseline_s0.8_m10 | 0/400 | 1.0032% | 5.5023 | 0.2869 |
| baseline_s0.35_m20 | 0/400 | 0.1123% | 5.5277 | 0.2976 |
| baseline_s0.8_m20 | 0/400 | 0.5267% | 5.5610 | 0.2911 |
| hierarchical_sampled_s0.35_m5 | 2/400 | 2.1580% | 6.0477 | 0.2851 |
| hierarchical_sampled_s0.8_m5 | 2/400 | 2.9207% | 6.6529 | 0.2986 |
| hierarchical_sampled_s0.35_m10 | 0/400 | 1.0165% | 6.2301 | 0.3302 |
| hierarchical_sampled_s0.8_m10 | 0/400 | 1.4879% | 6.4036 | 0.3053 |
| hierarchical_sampled_s0.35_m20 | 1/400 | 0.3446% | 6.2918 | 0.3268 |
| hierarchical_sampled_s0.8_m20 | 0/400 | 0.9532% | 6.5315 | 0.3211 |
| hierarchical_exact_s0.35_mexact | 0/400 | 0.1066% | 6.8227 | 0.3634 |
| hierarchical_exact_s0.8_mexact | 0/400 | 0.3589% | 6.1891 | 0.3227 |

Paired summaries require converged prototypes and qualified predictions for both methods; denominators are explicit. Distance relative errors additionally require d_F > 1e-7. Per-pair distances and qualification masks are in JSON. Timings use one BLAS thread. Shared methods reuse the Fisher fit; their reported training cost is that same fit cost, not another fit or a zero-cost prototype.

## Qualification

Fisher lengths use qualified horizontal solves with spectral, residual and endpoint checks, under the existing minimizing-geodesic assumption. Independent reduced-J checks use three starts. Neither checks nor optimizer success certify global minima.

- Reduced-J spot checks qualified and finite: 140/140; maximum discrepancy 8.72e-15.

Reproduce:

```powershell
python experiments/compare_mdm_sampled.py
python experiments/plot_mdm_sampled.py
```
