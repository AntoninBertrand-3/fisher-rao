# 10D Gaussian-law MDM comparison

**Partial run stopped at the user's request: 37 of 70 planned trials saved.**
The six baseline settings and hierarchical s=.35, m=15 have all five seeds.
Hierarchical s=.8, m=15 has only two seeds. Remaining settings, including
the exact-law control, were not completed. The commands below rerun the full
design; they do not resume or reproduce the stopping point.

Numerical observations on a fixed synthetic design; no universal performance claim.

Design and generator equations: [docs/mdm_benchmark.md](../docs/mdm_benchmark.md).

5 seeds; 12 training and 40 test laws per class. Spreads are fixed before evaluation: tau_mu=0.35, tau_Sigma=0.35.

Baseline: small batches from one parent per class. Hierarchical: a different latent law per observation, observed directly (exact) or estimated from a small batch (sampled). No shrinkage, seed selection, test tuning or failure filtering.

Naive uses arithmetic prototypes with Euclidean parameter distance. Fisher, d0 and Euclidean/shared use exactly the same estimated Fisher prototypes. d0 is a prediction approximation, not a separately optimized d0 Frechet mean.

| Scenario | s | Batch | Naive % | Fisher % | d0/shared % | Euclidean/shared % | Qualified Fisher trials |
|---|---:|---:|---:|---:|---:|---:|---:|
| baseline | 0.35 | 15 | 58.75 +/- 7.71 | 65.75 +/- 5.42 | 66.00 +/- 5.11 | 58.25 +/- 8.03 | 5/5 |
| baseline | 0.8 | 15 | 80.00 +/- 5.86 | 91.50 +/- 2.71 | 91.25 +/- 2.34 | 80.50 +/- 6.99 | 5/5 |
| baseline | 0.35 | 30 | 66.50 +/- 3.99 | 78.25 +/- 6.47 | 78.25 +/- 6.47 | 67.25 +/- 5.82 | 5/5 |
| baseline | 0.8 | 30 | 97.00 +/- 1.90 | 99.75 +/- 0.56 | 99.75 +/- 0.56 | 96.00 +/- 1.05 | 5/5 |
| baseline | 0.35 | 60 | 80.50 +/- 5.20 | 90.50 +/- 3.38 | 90.50 +/- 3.38 | 85.00 +/- 3.85 | 5/5 |
| baseline | 0.8 | 60 | 99.00 +/- 1.05 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 99.00 +/- 1.37 | 5/5 |
| hierarchical_sampled | 0.35 | 15 | 57.00 +/- 3.71 | 58.50 +/- 2.40 | 58.25 +/- 2.59 | 57.00 +/- 6.29 | 5/5 |
| hierarchical_sampled | 0.8 | 15 | 82.50 +/- 0.00 | 77.50 +/- 7.07 | 77.50 +/- 7.07 | 80.62 +/- 0.88 | 2/2 |

Variability is SD across seeds, not a confidence interval. Unqualified predictions are -1 and count as classification errors. Nonconverged prototype fits are flagged; their last-iterate accuracies remain visible in the table.

## Paired distance comparison on shared Fisher prototypes

| Family | d0 disagreements / qualified predictions | Max d0 relative distance error | Fisher prediction seconds | d0 prediction seconds |
|---|---:|---:|---:|---:|
| baseline_s0.35_m15 | 1/400 | 0.6386% | 43.9325 | 0.3622 |
| baseline_s0.8_m15 | 1/400 | 1.1053% | 59.0952 | 0.5525 |
| baseline_s0.35_m30 | 0/400 | 0.1379% | 46.8259 | 0.3946 |
| baseline_s0.8_m30 | 0/400 | 0.3275% | 45.8627 | 0.3555 |
| baseline_s0.35_m60 | 0/400 | 0.0428% | 40.7352 | 0.3656 |
| baseline_s0.8_m60 | 0/400 | 0.1471% | 44.0154 | 0.4208 |
| hierarchical_sampled_s0.35_m15 | 3/400 | 1.9990% | 51.0088 | 0.4769 |
| hierarchical_sampled_s0.8_m15 | 0/160 | 1.6757% | 15.7604 | 0.1382 |

Paired summaries require converged prototypes and qualified predictions for both methods; denominators are explicit. Distance relative errors additionally require d_F > 1e-7. Per-pair distances and qualification masks are in JSON. Timings use one BLAS thread. Shared methods reuse the Fisher fit; their reported training cost is that same fit cost, not another fit or a zero-cost prototype.

## Qualification

Fisher lengths use qualified horizontal solves with spectral, residual and endpoint checks, under the existing minimizing-geodesic assumption. Independent reduced-J checks use three starts. Neither checks nor optimizer success certify global minima.

- Reduced-J spot checks qualified and finite: 74/74; maximum discrepancy 8.79e-14.

Reproduce:

```powershell
python experiments/compare_mdm_sampled.py --dimension 10 --batch-sizes 15 30 60 --repeats 5 --train 12 --test 40 --mean-spread 0.35 --covariance-spread 0.35 --output "C:\Users\hanto\fisher-rao\results\mdm_sampled_10d"
python experiments/plot_mdm_sampled.py --input "C:\Users\hanto\fisher-rao\results\mdm_sampled_10d.csv"
```
