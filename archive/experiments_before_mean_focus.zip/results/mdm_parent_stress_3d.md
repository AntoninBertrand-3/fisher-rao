# Parent-stress MDM: dF versus triangle divergences

Fixed parent pair: A=N(0,I3), B=N((1,10,0),diag(.01,100,1)). This pair has dF=5.413124 and forward delta_c=7.251064 on the parent endpoints. Classes are generated from these parents; no test law is selected by a classifier disagreement.

| Batch | Fisher % | d0 % | delta_c % | delta_perp % |
|---:|---:|---:|---:|---:|
| 5 | 38.00 +/- 4.56 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 |
| 10 | 55.00 +/- 11.32 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 |
| 20 | 67.00 +/- 6.59 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 |
| exact | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 |

All five seeds use the same parent laws. SD is across seeds, not a confidence interval.
Triangle centers are fitted independently for each method. Raw diagnostics and all predictions are in JSON.
Reproduce: `python experiments/compare_triangle_parent_stress.py`.
