# Triangle divergence values versus d0 and numerical dF (3D)

Eight fixed illustrative pairs, not a worst-case search. Roots of the published squared divergences are displayed on the distance scale. They are generally asymmetric and need not bound dF. Squared values, both orientations and signed relative discrepancies are retained in CSV/JSON.

| Pair | dF | d0 forward | delta_c forward | delta_c reverse | delta_perp forward | delta_perp reverse | Qualified reference |
|---|---:|---:|---:|---:|---:|---:|---|
| identical | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | True |
| equal_means | 1.386294 | 1.386294 | 1.386294 | 1.386294 | 1.386294 | 1.386294 | True |
| mean_only | 1.862460 | 1.862460 | 1.862460 | 1.862460 | 1.797525 | 1.797525 | True |
| isotropic | 1.625574 | 1.625574 | 1.625574 | 1.625574 | 1.623033 | 1.578794 | True |
| mixed_diagonal | 2.210160 | 2.219585 | 2.146508 | 2.511750 | 2.133417 | 2.174677 | True |
| anisotropic | 3.729866 | 3.755906 | 3.643484 | 4.147331 | 3.513474 | 3.553429 | True |
| stress_L100 | 5.413124 | 5.912835 | 7.251064 | 7.251064 | 5.222309 | 5.222309 | True |
| mdm_parents_s0.8 | 1.152918 | 1.153386 | 1.085204 | 1.264628 | 1.136659 | 1.148132 | True |

## Explicit endpoints

The first seven pairs start at N(0,I_3).
- identical: first=[[0.0, 0.0, 0.0], [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]]; second=[[0.0, 0.0, 0.0], [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]].
- equal_means: first=[[0.0, 0.0, 0.0], [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]]; second=[[0.0, 0.0, 0.0], [[0.25, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 4.0]]].
- mean_only: first=[[0.0, 0.0, 0.0], [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]]; second=[[2.0, 0.0, 0.0], [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]].
- isotropic: first=[[0.0, 0.0, 0.0], [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]]; second=[[1.0, 1.0, 1.0], [[2.0, 0.0, 0.0], [0.0, 2.0, 0.0], [0.0, 0.0, 2.0]]].
- mixed_diagonal: first=[[0.0, 0.0, 0.0], [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]]; second=[[1.0, 1.0, 1.0], [[0.25, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 4.0]]].
- anisotropic: first=[[0.0, 0.0, 0.0], [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]]; second=[[1.0, 3.0, 1.0], [[0.1, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 10.0]]].
- stress_L100: first=[[0.0, 0.0, 0.0], [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]]; second=[[1.0, 10.0, 0.0], [[0.01, 0.0, 0.0], [0.0, 100.0, 0.0], [0.0, 0.0, 1.0]]].
- mdm_parents_s0.8: first=[[0.0, 0.0, 0.0], [[1.0, 0.0, 0.0], [0.0, 0.6, 0.0], [0.0, 0.0, 1.8]]]; second=[[0.6400000000000001, -0.4, 0.48], [[1.8173054363650385, 0.22759215553979806, -0.2738891558314559], [0.22759215553979806, 0.40046341273567504, 0.15873859986344518], [-0.2738891558314559, 0.15873859986344518, 2.1725529683987106]]].

## Numerical checks

Qualified references: 8/8.
Maximum horizontal/reduced discrepancy: 1.24e-14.
Maximum affine-invariance discrepancy (d0 and triangle roots): 6.28e-13.
Qualification is numerical under the existing minimizing-geodesic assumption; it is not a global proof.

Reproduce: `python experiments/compare_triangle_pairs.py`.
