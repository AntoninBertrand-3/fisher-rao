# Moderate-gap parent MDM: dF versus triangle divergences

Parent pair has condition number about 50 and endpoint dF/delta_c relative excess about 33.6%. No test law is selected by disagreement.

| Batch | Fisher % | d0 % | delta_c % | delta_perp % | Fisher coverage |
|---:|---:|---:|---:|---:|---:|
| 5 | 98.25 +/- 1.12 | 98.25 +/- 1.12 | 98.50 +/- 1.63 | 98.25 +/- 1.12 | 1.000 |
| 10 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 1.000 |
| 20 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 1.000 |
| exact | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 1.000 |

SD across five seeds. Fisher coverage is reported separately; unqualified dF predictions count as errors in accuracy.
Reproduce: `python experiments/compare_triangle_parent_gap.py`.
