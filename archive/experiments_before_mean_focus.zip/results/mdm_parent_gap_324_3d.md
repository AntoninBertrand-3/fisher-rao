# Moderate-gap parent MDM: dF versus triangle divergences

Parent seed 324; covariance condition number 21.24; endpoint delta_c/d_F excess 21.7%. No test law is selected by disagreement.

| Batch | Fisher % | d0 % | delta_c % | delta_perp % | Fisher coverage |
|---:|---:|---:|---:|---:|---:|
| 5 | 98.75 +/- 0.88 | 99.00 +/- 1.05 | 99.25 +/- 0.68 | 99.25 +/- 1.12 | 0.997 |
| 10 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 1.000 |
| 20 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 1.000 |
| exact | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 100.00 +/- 0.00 | 1.000 |

SD across five seeds. Fisher coverage is reported separately; unqualified dF predictions count as errors in accuracy.
Reproduce: `python experiments/compare_triangle_parent_gap.py`.
