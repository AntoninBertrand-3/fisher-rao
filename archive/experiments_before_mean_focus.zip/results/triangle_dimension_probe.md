# Dimension probe: triangle divergences versus d0 and dF

| n | Family | dF | d0 | delta_c | delta_perp | delta_c reverse | delta_perp reverse |
|---:|---|---:|---:|---:|---:|---:|---:|
| 3 | isotropic_mean | 1.625574 | 1.625574 | 1.625574 | 1.623033 | 1.625574 | 1.578794 |
| 3 | balanced_anisotropic | 2.949358 | 2.967302 | 2.826231 | 2.837068 | 3.651043 | 2.910787 |
| 3 | mixed_mean_anisotropic | 4.841290 | 4.861880 | 5.083409 | 4.676452 | 5.691735 | 4.644726 |
| 3 | strong_mixed | 7.729011 | 7.825511 | 7.269580 | 7.436680 | 11.755912 | 7.656169 |
| 5 | isotropic_mean | 2.063957 | 2.063957 | 2.063957 | 2.046328 | 2.063957 | 1.986089 |
| 5 | balanced_anisotropic | 3.418451 | 3.443106 | 3.291763 | 3.281418 | 4.056859 | 3.360887 |
| 5 | mixed_mean_anisotropic | 5.537231 | 5.579900 | 5.763173 | 5.400442 | 6.358942 | 5.423051 |
| 5 | strong_mixed | 8.760758 | 8.844164 | 8.237968 | 8.319778 | 12.329972 | 8.642498 |
| 10 | isotropic_mean | 2.818213 | 2.818213 | 2.818213 | 2.745247 | 2.818213 | 2.669324 |
| 10 | balanced_anisotropic | 4.409288 | 4.442426 | 4.267345 | 4.201359 | 4.998336 | 4.282865 |
| 10 | mixed_mean_anisotropic | 7.159411 | 7.235033 | 7.360409 | 7.009064 | 7.948881 | 7.056036 |
| 10 | strong_mixed | 11.053000 | 11.160476 | 10.448667 | 10.599257 | 14.129601 | 10.849947 |

All cases are fixed in advance; this is a probe, not a worst-case search.
Reference reliability and optimizer diagnostics are in JSON.
