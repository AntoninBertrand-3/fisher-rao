# Gaussian MDM comparison

Paired synthetic observations. Fisher/d0 results reused from the saved source; new prototypes use only the same training splits. d0 shares the Fisher prototype; covariance-only uses its SPD Frechet mean; mean-only uses its arithmetic mean.

Covariance distance uses the trace metric. Multiplying it by 1/sqrt(2) to match the covariance Fisher normalization changes neither prototypes nor predictions.

| Scenario | Separation | Batch | Seeds | fisher % | d0 % | covariance_only % | mean_only % | triangle_c % | triangle_perp % | Covariance fits converged |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline | 0.35 | 5 | 5 | 59.25 +/- 1.68 | 59.50 +/- 2.09 | 49.75 +/- 2.40 | 61.25 +/- 8.57 | 57.75 +/- 3.79 | 56.50 +/- 3.99 | 4/5 |
| baseline | 0.8 | 5 | 5 | 78.75 +/- 4.33 | 78.75 +/- 4.33 | 58.50 +/- 2.24 | 77.75 +/- 6.15 | 81.75 +/- 4.11 | 79.50 +/- 4.29 | 4/5 |
| baseline | 0.35 | 10 | 5 | 75.50 +/- 9.21 | 75.50 +/- 9.21 | 58.25 +/- 5.56 | 72.25 +/- 8.12 | 74.75 +/- 7.36 | 75.25 +/- 9.16 | 5/5 |
| baseline | 0.8 | 10 | 5 | 95.50 +/- 3.60 | 95.50 +/- 3.60 | 81.00 +/- 2.71 | 89.25 +/- 4.01 | 95.00 +/- 3.06 | 95.50 +/- 3.60 | 5/5 |
| baseline | 0.35 | 20 | 5 | 83.25 +/- 5.05 | 83.25 +/- 5.05 | 71.75 +/- 4.01 | 79.25 +/- 2.09 | 83.25 +/- 4.56 | 83.75 +/- 5.38 | 5/5 |
| baseline | 0.8 | 20 | 5 | 99.75 +/- 0.56 | 99.75 +/- 0.56 | 90.75 +/- 2.59 | 96.25 +/- 2.34 | 99.50 +/- 0.68 | 99.75 +/- 0.56 | 5/5 |
| hierarchical_sampled | 0.35 | 5 | 5 | 54.00 +/- 6.70 | 54.00 +/- 6.09 | 50.75 +/- 6.35 | 58.25 +/- 4.89 | 58.50 +/- 7.93 | 56.00 +/- 7.57 | 3/5 |
| hierarchical_sampled | 0.8 | 5 | 5 | 78.00 +/- 1.90 | 78.00 +/- 2.09 | 57.00 +/- 9.63 | 73.75 +/- 2.93 | 80.00 +/- 2.34 | 77.25 +/- 2.71 | 4/5 |
| hierarchical_sampled | 0.35 | 10 | 5 | 64.50 +/- 2.59 | 64.50 +/- 2.59 | 59.00 +/- 6.98 | 64.25 +/- 6.29 | 65.50 +/- 2.44 | 64.50 +/- 2.88 | 5/5 |
| hierarchical_sampled | 0.8 | 10 | 5 | 86.50 +/- 4.09 | 86.50 +/- 4.09 | 76.50 +/- 4.71 | 78.00 +/- 6.99 | 86.75 +/- 3.71 | 86.25 +/- 4.24 | 5/5 |
| hierarchical_sampled | 0.35 | 20 | 5 | 71.50 +/- 2.71 | 71.25 +/- 2.65 | 63.25 +/- 7.32 | 68.25 +/- 6.77 | 69.25 +/- 5.63 | 71.75 +/- 2.27 | 5/5 |
| hierarchical_sampled | 0.8 | 20 | 5 | 92.50 +/- 0.88 | 92.50 +/- 0.88 | 84.25 +/- 3.81 | 81.00 +/- 6.75 | 92.00 +/- 2.09 | 92.50 +/- 0.88 | 5/5 |
| hierarchical_exact | 0.35 | exact | 5 | 74.25 +/- 3.26 | 74.25 +/- 3.26 | 72.25 +/- 6.27 | 67.75 +/- 6.52 | 76.50 +/- 4.09 | 74.25 +/- 3.26 | 5/5 |
| hierarchical_exact | 0.8 | exact | 5 | 96.25 +/- 1.25 | 96.25 +/- 1.25 | 93.00 +/- 2.59 | 86.75 +/- 3.81 | 96.75 +/- 1.12 | 96.25 +/- 1.25 | 5/5 |

Variability is SD across seeds, not a confidence interval. Fisher distances retain the source minimizing-geodesic assumption. No universal superiority claim; these are complete pipeline comparisons.

Converged method/trial fits: 414/420.

Reproduce: `python experiments/compare_mdm_components.py --triangles`.

## Unresolved strict covariance-mean stopping checks

Last-iterate scores are retained without filtering. The tolerance is 1e-8 on the whitened mean-log norm; Armijo descent can stall near floating-point objective resolution. No tolerance was relaxed.
- baseline_s0.35_m5, seed 20261116, class 0: gradient norm 1.524e-08, iterations 20.
- baseline_s0.8_m5, seed 20261116, class 0: gradient norm 1.524e-08, iterations 20.
- hierarchical_sampled_s0.35_m5, seed 20261016, class 1: gradient norm 1.978e-07, iterations 22.
- hierarchical_sampled_s0.35_m5, seed 20261316, class 0: gradient norm 1.163e-08, iterations 40.
- hierarchical_sampled_s0.8_m5, seed 20261316, class 0: gradient norm 1.163e-08, iterations 40.

## Triangle center qualification

Each triangle has its own fitted center, minimizing equation (18). Both training and prediction put the center first. Formulas are the published squared divergences, without symmetrization. BFGS uses log-Cholesky coordinates and analytic gradients rather than the paper's retraction algorithm. Two deterministic starts do not certify global optimality.

- triangle_c: 139/140 centers qualified.
  - hierarchical_sampled_s0.8_m5, seed 20261016, class 1: {'success': False, 'message': 'Desired error not necessarily achieved due to precision loss.', 'iterations': 15, 'evaluations': 69, 'objective': 3.027133772417196, 'intrinsic_gradient_norm': 1.2776977816168003e-07, 'coordinate_gradient_norm': 1.0929611151477416e-07, 'qualified': False, 'initial_parameters': array([ 0.        ,  0.        ,  0.        , -0.5874866 ,  0.72927847,
       -0.37459984, -0.06348972, -0.08787369, -0.45302195]), 'final_parameters': array([-0.03568756, -0.03552936, -0.03250416, -0.1947506 ,  0.03461765,
       -0.32692189, -0.05943794, -0.1821798 , -0.25167843])}
- triangle_perp: 140/140 centers qualified.
