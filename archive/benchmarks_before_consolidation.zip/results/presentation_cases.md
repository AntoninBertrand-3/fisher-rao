# Compact comparison of d_0 and the numerical d_F reference

All pairs are N(0,I) versus N(mu,Sigma). Spectral ranges refer to covariance eigenvalues. Relative error is 100 |d_0-d_F|/d_F. The 16 cases were fixed before evaluation; no cases were removed.

| Case | Configuration | n | Mean norm | Spectrum | d_F (numerical) | d_0 | Relative error |
|---|---|---:|---:|---|---:|---:|---:|
| P01 | Univariate | 1 | 3 | [4, 4] | 2.136237 | 2.136237 | 0.0000% |
| P02 | Covariance only | 3 | 0 | [0.1, 10] | 2.302585 | 2.302585 | 0.0000% |
| P03 | Mean only, large shift | 5 | 20 | [1, 1] | 7.506990 | 7.506990 | 0.0000% |
| P04 | Isotropic expansion | 5 | 10 | [25, 25] | 5.956999 | 5.956999 | 0.0000% |
| P05 | Isotropic contraction | 5 | 10 | [0.04, 0.04] | 9.063695 | 9.063695 | 0.0000% |
| P06 | Anisotropic, aligned mean | 5 | 10 | [0.1, 10] | 4.632789 | 4.632789 | 0.0000% |
| P07 | Anisotropic, mixed mean | 5 | 10 | [0.1, 10] | 6.764626 | 6.773830 | 0.1361% |
| P08 | Strong anisotropy, mixed mean | 5 | 20 | [0.01, 100] | 9.756152 | 9.831539 | 0.7727% |
| P09 | Moderate spectrum | 12 | 3 | [0.5, 2] | 2.962648 | 2.965256 | 0.0880% |
| P10 | Large mean shift | 12 | 30 | [0.5, 2] | 8.781329 | 8.781836 | 0.0058% |
| P11 | Anisotropic, mixed mean | 20 | 10 | [0.1, 10] | 7.184400 | 7.227034 | 0.5934% |
| P12 | Strong anisotropy, mixed mean | 20 | 20 | [0.01, 100] | 12.316006 | 12.337309 | 0.1730% |
| P13 | Moderate spectrum | 30 | 10 | [0.5, 2] | 6.030420 | 6.033198 | 0.0461% |
| P14 | Anisotropic, large mean shift | 30 | 30 | [0.1, 10] | 10.940244 | 10.946325 | 0.0556% |
| P15 | Stress family, L=100 | 2 | 10.05 | [0.01, 100] | 5.413124 | 5.912835 | 9.2315% |
| P16 | Stress family, L=1000 | 2 | 31.64 | [0.001, 1000] | 7.717864 | 8.993768 | 16.5318% |

## Reference qualification

The reference minimizes the repository's canonical J(K) using analytic-gradient BFGS with five starts (zero plus four seeded Gaussian starts), gtol=1e-8 and maxiter=2000. Three further starts solve each pair with reversed endpoints. Convergence and agreement are numerical checks, not a certificate of global optimality or an independent proof of the reduced identity.

Forward converged references: 10/16. Reverse converged references: 11/16. Maximum forward/reverse distance discrepancy: 1.95e-14.

When strict BFGS reports precision loss, an additional five-start solve uses gtol=1e-6. A reference is qualified only when that solve converges and agrees with the strict result within 1e-9 in distance, and endpoint reversal agrees within 1e-9. The strict results and diagnostics are retained, including unsuccessful terminations.

References passing these numerical checks: 16/16. Maximum tolerance-check discrepancy: 1.25e-12.

Covariances are diagonal representatives: generic mixed means still require full skew optimization. A common invertible affine transformation produces equivalent pairs with noncommuting covariances. The last two rows explicitly probe the historical anisotropic stress family mu=(1,sqrt(L)), Sigma=diag(1/L,L). They are not representative random samples.

Full endpoints, seeds, timings, solver settings and restart diagnostics are in presentation_cases.csv. Historical asymptotic claims are not assumed in interpreting these results.

The companion presentation_validation.json records a separate Brent scalar optimization of each 2D stress case and an affine-invariance check of P08 with noncommuting endpoint covariances. These checks use the same reduced objective, not an independent Fisher geodesic solver. Displayed zero errors mean agreement at the displayed precision.
