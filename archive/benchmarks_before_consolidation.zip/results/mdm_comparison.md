# Synthetic Gaussian MDM comparison

Numerical observations, not a claim of universal classification superiority.

Naive: separate arithmetic means and sqrt(||delta_mu||² + ||delta_Sigma||_F²). Fisher: estimated Frechet prototypes and qualified horizontal-geodesic lengths. Both use identical held-out samples. Each descriptor is an exact Gaussian; finite-sample estimation of descriptors is not simulated.

Planned design: 5 independent seeds, 12 train and 40 test descriptors per class; two balanced classes. Reported standard deviations are across replicate accuracies (ddof=1), not confidence intervals.

| Family | Trials | Naive accuracy (mean ± SD) | Fisher accuracy (mean ± SD) | Paired gain (pp ± SD) | Qualified Fisher trials |
|---|---:|---:|---:|---:|---:|
| tight_fisher | 5 | 96.75 ± 1.90% | 99.25 ± 0.68% | +2.50 ± 2.17 | 5/5 |
| broad_fisher | 5 | 67.50 ± 8.62% | 80.25 ± 4.28% | +12.75 ± 8.90 | 5/5 |
| broad_fisher_scaled | 5 | 63.75 ± 3.19% | 80.25 ± 4.28% | +16.50 ± 6.75 | 5/5 |
| parameter_cloud | 5 | 91.50 ± 2.71% | 84.75 ± 2.05% | -6.75 ± 0.68 | 5/5 |
| coupled_mixture | 5 | 45.00 ± 4.33% | 51.75 ± 2.74% | +6.75 ± 5.42 | 5/5 |

## Fixed generators

- `tight_fisher` / `broad_fisher`: 2D tangent-normal samples mapped by the Fisher exponential around m0=(-.6,-.2), C0=diag(.7,1.6), m1=(.6,.2), C1=R(.6)diag(1.6,.7)R(.6). Normalized tangent components are independent normal: a_j~N(0,s²), A_jj~N(0,2s²), A_12~N(0,s²), s=.3 or .9. This construction is favorable in principle to intrinsic geometry; it is not an unbiased model of real data.
- `parameter_cloud`: same 2D centers; means have additive N(0,.75² I) noise; covariance noise is a random symmetric matrix rescaled to spectral norm .4 U, U~Uniform(0,1). This provides a contrasting parameter-space construction.
- `coupled_mixture`: 1D deliberately multimodal classes. Equiprobable side z=±1; mu=2z+.35(2c-1)+.35 epsilon. Variance is 9 exp(.25 eta) if z=1-2c, otherwise exp(.25 eta); epsilon and eta are independent standard normals. One prototype per class need not represent these mixtures well.
- `broad_fisher_scaled`: exactly the same broad samples, transformed by B=diag(3,.3), b=(1,-2). Both classifiers are refitted, without tuning their settings.

All seeds and outputs are retained, without selection on accuracy. Training and test RNG seeds are separate. No test observations are used to fit or choose prototypes. Ties go to class 0 for both methods. Accuracy equals balanced accuracy because classes have equal sizes.

Unqualified predictions are marked -1 and counted as errors. Nonconverged prototype fits are flagged even if a last iterate can be classified. Qualified-trial counts require both converged fits and full prediction coverage. The JSON retains every distance qualification and restart termination, mean history, endpoint, prototype and prediction. The minimizing-horizontal-geodesic assumption remains explicit; no global mean is certified.

## Feature-scale check

- Seed 20261015: changed predictions naive=16, Fisher=0.
- Seed 20261115: changed predictions naive=16, Fisher=0.
- Seed 20261215: changed predictions naive=2, Fisher=0.
- Seed 20261315: changed predictions naive=25, Fisher=0.
- Seed 20261415: changed predictions naive=6, Fisher=0.

## Runtime and independent checks

- naive: total training 0.006 s; total prediction 0.108 s (one BLAS thread).
- fisher: total training 56.796 s; total prediction 37.147 s (one BLAS thread).
- Independent reduced-objective checks qualified: 50/50; maximum length discrepancy: 4.11e-15.
