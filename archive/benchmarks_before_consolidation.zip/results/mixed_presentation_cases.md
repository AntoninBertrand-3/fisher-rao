# Mixed diagonal and dense covariance comparison

All first means are zero. Mean norm denotes ||mu1|| in the original coordinates. The condition number is that of Sigma0^(-1/2) Sigma1 Sigma0^(-1/2). P identifiers retain old cases; D identifiers denote new cases fixed before evaluation.

| Case | Configuration | n | Mean norm | Covariance structure | d_F numerical | d_0 | Relative error |
|---|---|---:|---:|---|---:|---:|---:|
| P01 | Univariate | 1 | 3 | diagonal | 2.136237 | 2.136237 | 0.0000% |
| P02 | Covariance only | 3 | 0 | diagonal | 2.302585 | 2.302585 | 0.0000% |
| P03 | Mean only, large shift | 5 | 20 | diagonal | 7.506990 | 7.506990 | 0.0000% |
| P07 | Anisotropic, mixed mean | 5 | 10 | diagonal | 6.764626 | 6.773830 | 0.1361% |
| P08 | Strong anisotropy, mixed mean | 5 | 20 | diagonal | 9.756152 | 9.831539 | 0.7727% |
| P14 | Anisotropic, large mean shift | 30 | 30 | diagonal | 10.940244 | 10.946325 | 0.0556% |
| D01 | Explicit dense covariance | 2 | 2.236 | identity / dense | 2.506408 | 2.509259 | 0.1138% |
| D02 | Dense, mixed mean | 5 | 10 | identity / dense | 6.290485 | 6.414111 | 1.9653% |
| D03 | Dense, large mean shift | 12 | 30 | identity / dense | 8.611240 | 8.611870 | 0.0073% |
| D04 | Dense, strong anisotropy | 20 | 20 | identity / dense | 12.754899 | 12.772306 | 0.1365% |
| D05 | Dense, dimension 30 | 30 | 10 | identity / dense | 5.852342 | 5.856426 | 0.0698% |
| D06 | Two dense, noncommuting | 5 | 10 | dense / dense | 7.286521 | 7.322419 | 0.4927% |
| D07 | Two dense, noncommuting | 20 | 20 | dense / dense | 10.898896 | 10.937751 | 0.3565% |
| P15 | Stress family, L=100 | 2 | 10.05 | diagonal | 5.413124 | 5.912835 | 9.2315% |

## Precise constructions

P01, P02, P03, P07, P08, P14 and P15 retain the endpoints of presentation_endpoints.json. Every actual endpoint in the new table is also stored at full precision in mixed_presentation_cases.json.

D01: mu1=(2,-1), Sigma0=I2, Sigma1=[[2,1.5],[1.5,2]].

For D02-D07, use numpy.random.default_rng(seed). Each dense covariance is Q diag(geomspace(a,b,n)) Q.T, where Q is the QR basis of a fresh standard-normal n by n matrix, with QR diagonal signs made positive. Generate Sigma0 if nonidentity, then Sigma1, then z=standard_normal(n) and mu1=r*z/||z||. The two dense endpoint covariances use independent bases, not a common rotation of an old pair.

| Case | Seed | Spectrum Sigma0 | Spectrum Sigma1 | r |
|---|---:|---|---|---:|
| D02 | 20260930 | [1,1] | [0.1,10] | 10 |
| D03 | 20260931 | [1,1] | [0.5,2] | 30 |
| D04 | 20260932 | [1,1] | [0.01,100] | 20 |
| D05 | 20260933 | [1,1] | [0.5,2] | 10 |
| D06 | 20260934 | [0.5,2] | [0.1,10] | 10 |
| D07 | 20260935 | [0.2,5] | [0.05,20] | 20 |

## Numerical checks

The primary reference uses five-start analytic-gradient BFGS, gtol=1e-6, maxiter=2000. Checks use two strict starts at gtol=1e-8, three reversed-endpoint starts at gtol=1e-6, available exact cases, and the diagonal-path upper bound after normalization. Precision-loss diagnostics of strict solves are preserved. A qualified row requires converged primary and reverse results and distance agreement within 1e-8.

Qualified cases: 14/14. Maximum strict/reverse discrepancy: 5.02e-12.

These checks establish numerical consistency, not certified global minima or a proof of the reduced Fisher-distance identity. Zero displayed errors mean agreement at displayed precision. P15 remains as an explicit stress case; no new case was removed based on its result.
