# Same fourteen pairs: BFGS on the horizontality condition

Exact endpoints are loaded from mixed_presentation_cases.json. Mean norms and covariance structures use the same original coordinates as the previous table. The working assumption is that the horizontal lift projects to the minimizing Fisher geodesic.

| Case | Configuration | n | Mean norm | Covariance structure | d_F horizontal | d_0 | Relative error |
|---|---|---:|---:|---|---:|---:|---:|
| P01 | Univariate | 1 | 3 | diagonal | 2.136237 | 2.136237 | 0.0000% |
| P02 | Covariance only | 3 | 0 | diagonal | 2.302585 | 2.302585 | 0.0000% |
| P03 | Mean only, large shift | 5 | 20 | diagonal | 7.506990 | 7.506990 | 0.0000% |
| P07 | Anisotropic, mixed mean | 5 | 10 | diagonal | 6.764626 | 6.773830 | 0.1361% |
| P08 | Strong anisotropy, mixed mean | 5 | 20 | diagonal | 9.756152 | 9.831539 | 0.7727% |
| P14 | Anisotropic, large mean shift | 30 | 30 | diagonal | 10.940244 | 10.946325 | 0.0556% |
| D01 | Explicit dense covariance | 2 | 2.236 | identity / dense | 2.506408 | 2.509259 | 0.1138% |
| D02 | Dense, mixed mean | 5 | 10 | identity / dense | 6.290485 | 6.414111 | 1.9653% |
| D03 | Dense, large mean shift | 12 | 30 | identity / dense | 8.611240 | 8.611870 | 0.0073% |
| D04 | Dense, strong anisotropy | 20 | 20 | identity / dense | 12.754899 | 12.772306 | 0.1365% |
| D05 | Dense, dimension 30 | 30 | 10 | identity / dense | 5.852342 | 5.856426 | 0.0698% |
| D06 | Two dense, noncommuting | 5 | 10 | dense / dense | 7.286521 | 7.322419 | 0.4927% |
| D07 | Two dense, noncommuting | 20 | 20 | dense / dense | 10.898896 | 10.937751 | 0.3565% |
| P15 | Stress family, L=100 | 2 | 10.05 | diagonal | 5.413124 | 5.912835 | 9.2315% |

## Horizontality and comparison with the previous reference

| Case | Primary residual (screened) | Final residual | Difference from old d_F | Strict/reverse discrepancy | Qualified |
|---|---:|---:|---:|---:|---|
| P01 | 8.04e-16 | 8.04e-16 | 1.33e-15 | 1.33e-15 | True |
| P02 | 0 | 0 | 0 | 0 | True |
| P03 | 3.51e-15 | 3.51e-15 | 1.69e-14 | 0 | True |
| P07 | 5.83e-08 | 9.57e-13 | 5.33e-15 | 4.44e-15 | True |
| P08 | 2.44e-07 | 2.2e-13 | 2.13e-14 | 9.24e-14 | True |
| P14 | 0.000471 | 7.64e-10 | 2.95e-13 | 5.15e-14 | True |
| D01 | 6.62e-11 | 3.71e-13 | 8.88e-16 | 1.33e-15 | True |
| D02 | 2.27e-07 | 7.07e-13 | 3.55e-15 | 0 | True |
| D03 | 9.9e-05 | 8.61e-10 | 7.28e-14 | 3.2e-14 | True |
| D04 | 0.00107 | 1.7e-11 | 5.45e-13 | 7.64e-14 | True |
| D05 | 1.94e-05 | 9.73e-11 | 1.7e-13 | 0 | True |
| D06 | 2.16e-07 | 1.12e-12 | 9.77e-15 | 1.78e-14 | True |
| D07 | 0.000617 | 2.4e-11 | 9.86e-13 | 1.24e-14 | True |
| P15 | 2.4e-08 | 4.84e-13 | 8.88e-16 | 4.44e-15 | True |

## Method and qualification

The minimized objective is R(S)=||(log G(S))_13||_F^2, using the endpoint fiber in notation.md section 7. The distance is evaluated afterward as ||log G||_F/2. The analytic gradient uses the spectral Frechet derivative of log and its adjoint; BFGS does not use finite differences or a distance objective.

The matching primary run uses the original five starting vectors (zero plus four seeded standard-normal upper-triangle vectors), gtol=1e-6 and maxiter=2000. The same numerical coordinates now represent S, with no assumed S-to-K mapping. Two strict starts use gtol=1e-8 and seed+1000; three reversed-endpoint starts use gtol=1e-6 and seed+2000.

If the primary/strict/reverse residual exceeds 1e-7, or distance agreement exceeds 1e-8, additional BFGS runs restart from the original vectors at gtol=1e-11 and maxiter=5000 (five forward, three reverse). Raw original-settings results are retained. Final candidates are selected by the smallest residual among spectrally resolved runs, never by distance. A qualified row requires converged forward and reverse selections, both residuals <=1e-7, agreement <=1e-8, and available exact-distance and diagonal-path-upper-bound checks.

Spectral screening requires eps*cond(L)<=1e-6, ||H+J H J||_F<=1e-7, and |trace(H)|<=1e-7. These are diagnostic screens, not certified error bounds. All final spectra are additionally checked with a different LAPACK SVD driver. The raw minimum and every rejected restart remain in JSON.

A D07 random restart illustrates the failure mode: BFGS reported success with a computed residual of 6.92e-8 and an apparent distance of 132.040111, but ||H+J H J||_F was 322 and trace(H) was 1008. Its spectrum is unresolved, so this is not a horizontal solution. The valid refined solution gives 10.898896. Several other random restarts escaped to large fiber parameters or reported precision loss; a small objective-gradient norm alone is insufficient.

Qualified rows: 14/14. Maximum difference from the old distance: 9.86e-13. Maximum selected horizontal residual: 8.61e-10.

All endpoints, initial/final coordinates, residuals, gradients, optimizer termination flags, timings and directional-gradient checks are saved in the companion JSON. Timings use one BLAS thread and include preparation plus the stated restarts; they are not directly comparable with the older run on an unspecified thread count. The CSV separates matching-primary runtime from additional validation and refinement cost.

These are numerical results under the stated minimizing-geodesic assumption, not a proof of that assumption or the reduced-distance identity. No case was removed. See experiments/horizontality_derivation.md for the full gradient and metric derivation.
