"""Regenerate the MDM accuracy figure from stored CSV results (requires matplotlib)."""

import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    """Plot replicate accuracy and paired gains without rerunning any solvers."""
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=root / 'results' / 'mdm_comparison.csv')
    args = parser.parse_args()
    with args.input.open(encoding='utf-8', newline='') as stream:
        rows = list(csv.DictReader(stream))
    families = list(dict.fromkeys(row['family'] for row in rows))
    labels = {'tight_fisher': 'Tight Fisher\nclusters (2D)',
              'broad_fisher': 'Broad Fisher\nclusters (2D)',
              'broad_fisher_scaled': 'Same broad data\nchanged units',
              'parameter_cloud': 'Parameter-space\nclouds (2D)',
              'coupled_mixture': 'Coupled mixtures\n(1D)'}
    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True,
                             gridspec_kw={'height_ratios': [2, 1]}, layout='constrained')
    x = np.arange(len(families))
    scores = {}
    for method, color, offset, label in [('naive', '#56718f', -.17, 'Arithmetic mean + Euclidean parameter distance'),
                                          ('fisher', '#c56a26', .17, 'Estimated Fisher mean + Fisher distance')]:
        values = []
        for family in families:
            selected = sorted((row for row in rows if row['family'] == family and row['method'] == method),
                              key=lambda row: int(row['seed']))
            values.append(np.array([100 * float(row['accuracy']) for row in selected]))
        scores[method] = values
        averages = np.array([value.mean() for value in values])
        deviations = np.array([value.std(ddof=1) if len(value) > 1 else 0 for value in values])
        axes[0].bar(x + offset, averages, width=.32, color=color, alpha=.8, label=label)
        axes[0].errorbar(x + offset, averages, yerr=deviations, fmt='none', ecolor='#222222', capsize=3)
        for index, value in enumerate(values):
            axes[0].scatter(index + offset + np.linspace(-.08, .08, len(value)), value,
                            s=14, color='#222222', zorder=4)
    differences = [fisher - naive for fisher, naive in zip(scores['fisher'], scores['naive'])]
    axes[1].axhline(0, color='#777777', linewidth=1)
    axes[1].errorbar(x, [value.mean() for value in differences],
                     yerr=[value.std(ddof=1) if len(value) > 1 else 0 for value in differences],
                     fmt='o', color='#c56a26', capsize=4)
    for index, value in enumerate(differences):
        axes[1].scatter(index + np.linspace(-.08, .08, len(value)), value, color='#555555', s=15)
    axes[0].set_ylim(0, 105)
    axes[0].set_ylabel('Held-out accuracy (%)')
    axes[0].legend(loc='lower left', fontsize=9)
    axes[0].set_title('Synthetic Gaussian MDM: complete classifier comparison\n'
                       'Dots: individual seeds. Error bars: standard deviation across seeds, not confidence intervals.')
    axes[1].set_ylabel('Fisher − naive\n(percentage points)')
    axes[1].set_xticks(x, [labels.get(family, family) for family in families])
    for axis in axes:
        axis.spines[['top', 'right']].set_visible(False)
        axis.grid(axis='y', alpha=.2)
        axis.set_axisbelow(True)
    for suffix in ('.png', '.svg'):
        fig.savefig(args.input.with_suffix(suffix), dpi=180)
    plt.close(fig)


if __name__ == '__main__':
    main()
