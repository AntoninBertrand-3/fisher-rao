"""Reevaluate the fourteen saved pairs by analytic-gradient horizontality BFGS.

Run: python experiments/horizontal_presentation_cases.py
The saved endpoint JSON is authoritative. Existing benchmark files are read only.
"""

import argparse
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys
from time import perf_counter

import numpy as np
import scipy
from scipy.optimize import minimize
from threadpoolctl import threadpool_info, threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from fisher_rao import d_0, normalize_pair
from fisher_rao.horizontality import HorizontalFiberObjective, lift_spectrum_resolved

RESIDUAL_TOLERANCE = 1e-7
DISTANCE_TOLERANCE = 1e-8


def select_run(result: dict) -> None:
    """Select the smallest residual among spectrally resolved saved restarts.

    Parameters
    ----------
    result : dict
        Solver group updated in place, retaining the raw minimum and all runs.
    """
    runs = result['runs']
    for run in runs:
        run['spectrally_resolved'] = lift_spectrum_resolved(
            run['lift_condition'], run['log_structure_error'], run['log_determinant'])
    raw_index = min(range(len(runs)), key=lambda index: runs[index]['objective'])
    eligible = [index for index, run in enumerate(runs) if run['spectrally_resolved']]
    selected_index = min(eligible or range(len(runs)), key=lambda index: runs[index]['objective'])
    selected = runs[selected_index]
    result.update(raw_selected_index=raw_index, raw_distance=runs[raw_index]['distance'],
                  raw_horizontal_residual=runs[raw_index]['horizontal_residual'],
                  raw_selection_spectrally_resolved=runs[raw_index]['spectrally_resolved'],
                  selected_index=selected_index, distance=selected['distance'],
                  horizontal_residual=selected['horizontal_residual'], converged=selected['success'],
                  spectrally_resolved=selected['spectrally_resolved'],
                  horizontal=selected['spectrally_resolved'] and selected['horizontal_residual'] <= RESIDUAL_TOLERANCE)


def solve_fiber(args: tuple, seed: int, n_starts: int, gtol: float, maxiter: int) -> dict:
    """Solve only the horizontal residual from reproducible original coordinates.

    Parameters
    ----------
    args : tuple
        Original Gaussian endpoint arrays (mu0, Sigma0, mu1, Sigma1).
    seed : int
        Local random restart seed.
    n_starts : int
        Count including the zero start.
    gtol : float
        BFGS infinity-norm gradient stopping tolerance.
    maxiter : int
        Maximum BFGS iterations per start.

    Returns
    -------
    dict
        Selected residual, distance candidate, every start and raw diagnostics.
    """
    start_time = perf_counter()
    objective = HorizontalFiberObjective(*normalize_pair(*args))
    generator = np.random.default_rng(seed)
    runs = []
    for index in range(n_starts if objective.parameter_count else 1):
        initial = (np.zeros(objective.parameter_count) if index == 0
                   else generator.standard_normal(objective.parameter_count))
        run_start = perf_counter()
        if objective.parameter_count:
            result = minimize(objective.value_and_gradient, initial, jac=True, method='BFGS',
                              options=dict(gtol=gtol, maxiter=maxiter))
            parameters = result.x
            value, gradient = objective.value_and_gradient(parameters)
            run = dict(success=bool(result.success), status=int(result.status),
                       message=str(result.message), nit=int(result.nit), nfev=int(result.nfev),
                       njev=int(result.njev))
        else:
            parameters = initial
            value, gradient = objective.value_and_gradient(parameters)
            run = dict(success=True, status=0, message='No skew coordinates.', nit=0, nfev=1, njev=1)
        run.update(objective.diagnostics(parameters))
        run.update(initial_parameters=initial.tolist(), parameters=parameters.tolist(),
                   objective=value, gradient_norm=float(np.linalg.norm(gradient)),
                   gradient_inf_norm=float(np.max(np.abs(gradient), initial=0)),
                   runtime=perf_counter() - run_start)
        runs.append(run)
    result = dict(seed=seed, n_starts=n_starts, gtol=gtol, maxiter=maxiter,
                  runtime=perf_counter() - start_time, runs=runs)
    select_run(result)
    return result


def directional_gradient_check(args: tuple, seed: int) -> dict:
    """Check analytic directional derivatives at a seeded nonzero fiber point.

    Parameters
    ----------
    args : tuple
        Original Gaussian endpoint arrays.
    seed : int
        Seed for independent point and direction draws.

    Returns
    -------
    dict
        Analytic derivative and centered finite differences at three step sizes.
    """
    objective = HorizontalFiberObjective(*normalize_pair(*args))
    if not objective.parameter_count:
        return dict(applicable=False, reason='No skew coordinates.')
    rng = np.random.default_rng(seed + 5000)
    point = rng.standard_normal(objective.parameter_count)
    direction = rng.standard_normal(objective.parameter_count)
    direction /= np.linalg.norm(direction)
    analytic = float(objective.value_and_gradient(point)[1] @ direction)
    steps = []
    for epsilon in (1e-3, 1e-4, 1e-5):
        plus = objective.value_and_gradient(point + epsilon * direction)[0]
        minus = objective.value_and_gradient(point - epsilon * direction)[0]
        numerical = (plus - minus) / (2 * epsilon)
        steps.append(dict(step=epsilon, numerical=numerical, absolute_error=abs(numerical - analytic)))
    return dict(applicable=True, point=point.tolist(), direction=direction.tolist(),
                analytic=analytic, steps=steps)


def save_results(records: list[dict], metadata: dict) -> None:
    """Save complete diagnostics, a compact CSV and the comparison table.

    Parameters
    ----------
    records : list of dict
        Completed case records with exact endpoints and all solves.
    metadata : dict
        Input hash, numerical conventions and execution environment.
    """
    output = ROOT / 'results'
    (output / 'horizontal_presentation_cases.json').write_text(
        json.dumps(dict(metadata=metadata, cases=records), indent=2) + '\n', encoding='utf-8')
    rows = [record['summary'] for record in records]
    with (output / 'horizontal_presentation_cases.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = ['# Same fourteen pairs: BFGS on the horizontality condition', '',
             'Exact endpoints are loaded from mixed_presentation_cases.json. Mean norms and covariance '
             'structures use the same original coordinates as the previous table. '
             'The working assumption is that the horizontal lift projects to the minimizing Fisher geodesic.', '',
             '| Case | Configuration | n | Mean norm | Covariance structure | d_F horizontal | d_0 | Relative error |',
             '|---|---|---:|---:|---|---:|---:|---:|']
    for row in rows:
        lines.append(f"| {row['case']} | {row['description']} | {row['n']} | {row['mean_norm']:.4g} | "
                     f"{row['covariance_structure']} | {row['d_f']:.6f} | {row['d_0']:.6f} | "
                     f"{100 * row['relative_error']:.4f}% |")
    lines += ['', '## Horizontality and comparison with the previous reference', '',
              '| Case | Primary residual (screened) | Final residual | Difference from old d_F | Strict/reverse discrepancy | Qualified |',
              '|---|---:|---:|---:|---:|---|']
    for row in rows:
        lines.append(f"| {row['case']} | {row['primary_residual']:.3g} | {row['horizontal_residual']:.3g} | "
                     f"{row['old_distance_difference']:.3g} | {row['validation_discrepancy']:.3g} | {row['qualified']} |")
    lines += ['', '## Method and qualification', '',
              'The minimized objective is R(S)=||(log G(S))_13||_F^2, using the endpoint fiber '
              'in notation.md section 7. The distance is evaluated afterward as ||log G||_F/2. '
              'The analytic gradient uses the spectral Frechet derivative of log and its adjoint; '
              'BFGS does not use finite differences or a distance objective.', '',
              'The matching primary run uses the original five starting vectors (zero plus four seeded '
              'standard-normal upper-triangle vectors), gtol=1e-6 and maxiter=2000. The same numerical '
              'coordinates now represent S, with no assumed S-to-K mapping. Two strict starts use '
              'gtol=1e-8 and seed+1000; three reversed-endpoint starts use gtol=1e-6 and seed+2000.', '',
              'If the primary/strict/reverse residual exceeds 1e-7, or distance agreement exceeds 1e-8, '
              'additional BFGS runs restart from the original vectors at gtol=1e-11 and maxiter=5000 '
              '(five forward, three reverse). Raw original-settings results are retained. '
              'Final candidates are selected by the smallest residual among spectrally resolved runs, never by distance. '
              'A qualified row requires converged forward and reverse selections, both residuals <=1e-7, '
              'agreement <=1e-8, and available exact-distance and diagonal-path-upper-bound checks.', '',
              'Spectral screening requires eps*cond(L)<=1e-6, ||H+J H J||_F<=1e-7, and '
              '|trace(H)|<=1e-7. These are diagnostic screens, not certified error bounds. '
              'All final spectra are additionally checked with a different LAPACK SVD driver. '
              'The raw minimum and every rejected restart remain in JSON.', '',
              'A D07 random restart illustrates the failure mode: BFGS reported success with a computed '
              'residual of 6.92e-8 and an apparent distance of 132.040111, but '
              '||H+J H J||_F was 322 and trace(H) was 1008. Its spectrum is unresolved, '
              'so this is not a horizontal solution. The valid refined solution gives 10.898896. '
              'Several other random restarts escaped to large fiber parameters or reported precision loss; '
              'a small objective-gradient norm alone is insufficient.', '',
              f"Qualified rows: {sum(row['qualified'] for row in rows)}/{len(rows)}. "
              f"Maximum difference from the old distance: {max(row['old_distance_difference'] for row in rows):.3g}. "
              f"Maximum selected horizontal residual: {max(row['horizontal_residual'] for row in rows):.3g}.", '',
              'All endpoints, initial/final coordinates, residuals, gradients, optimizer termination flags, '
              'timings and directional-gradient checks are saved in the companion JSON. '
              'Timings use one BLAS thread and include preparation plus the stated restarts; '
              'they are not directly comparable with the older run on an unspecified thread count. '
              'The CSV separates matching-primary runtime from additional validation and refinement cost.', '',
              'These are numerical results under the stated minimizing-geodesic assumption, '
              'not a proof of that assumption or the reduced-distance identity. No case was removed. '
              'See experiments/horizontality_derivation.md for the full gradient and metric derivation.']
    (output / 'horizontal_presentation_cases.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def refresh_saved_results() -> None:
    """Apply spectral screening to saved raw runs and regenerate report files."""
    path = ROOT / 'results' / 'horizontal_presentation_cases.json'
    data = json.loads(path.read_text(encoding='utf-8'))
    for record in data['cases']:
        for stage in ('primary', 'strict', 'reverse', 'refined', 'refined_reverse'):
            if record[stage] is not None:
                select_run(record[stage])
        primary = record['primary']
        summary = record['summary']
        summary.update(primary_residual=primary['horizontal_residual'], primary_distance=primary['distance'],
                       primary_converged=primary['converged'],
                       raw_primary_distance=primary['raw_distance'],
                       raw_primary_residual=primary['raw_horizontal_residual'],
                       raw_primary_spectrally_resolved=primary['raw_selection_spectrally_resolved'])
        # Final selected solutions were independently validated; screening must not change them.
        candidates = [record[stage] for stage in ('primary', 'strict', 'refined') if record[stage] is not None]
        selected = min(candidates, key=lambda result: result['horizontal_residual'])
        assert selected['spectrally_resolved'] and selected['distance'] == summary['d_f']
    data['metadata']['selection'] = 'minimum residual among spectrally resolved runs, never distance'
    data['metadata']['spectral_screen'] = dict(max_eps_factor_condition=1e-6, max_structure_error=1e-7,
                                             max_absolute_log_determinant=1e-7)
    save_results(data['cases'], data['metadata'])


def main() -> None:
    """Run the unchanged endpoint suite and preserve every solver outcome."""
    source = ROOT / 'results' / 'mixed_presentation_cases.json'
    source_bytes = source.read_bytes()
    previous_records = json.loads(source_bytes)
    metadata = dict(source=str(source.relative_to(ROOT)), source_sha256=hashlib.sha256(source_bytes).hexdigest(),
                    python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
                    residual_tolerance=RESIDUAL_TOLERANCE, distance_tolerance=DISTANCE_TOLERANCE,
                    distance_definition='norm(log(G), fro)/2 at horizontality',
                    minimized_objective='norm(log(G)[0:n,n+1:2*n+1], fro)**2',
                    minimizing_projection_assumed=True,
                    selection='minimum residual among spectrally resolved runs, never distance',
                    spectral_screen=dict(max_eps_factor_condition=1e-6, max_structure_error=1e-7,
                                         max_absolute_log_determinant=1e-7))
    records = []
    with threadpool_limits(limits=1):
        metadata['threadpools'] = threadpool_info()
        for previous in previous_records:
            case_start = perf_counter()
            args = tuple(np.asarray(previous[key], dtype=float) for key in ('mu0', 'covariance0', 'mu1', 'covariance1'))
            reverse_args = (args[2], args[3], args[0], args[1])
            seed = previous['seed']
            print(f"{previous['case']}: primary five-start BFGS", flush=True)
            primary = solve_fiber(args, seed, 5, 1e-6, 2000)
            print(f"  primary residual={primary['horizontal_residual']:.3g}; strict/reverse checks", flush=True)
            strict = solve_fiber(args, seed + 1000, 2, 1e-8, 2000)
            reverse = solve_fiber(reverse_args, seed + 2000, 3, 1e-6, 2000)
            forward_candidates = [primary, strict]
            reverse_candidates = [reverse]
            refined = refined_reverse = None
            initial_discrepancy = max(abs(primary['distance'] - strict['distance']),
                                      abs(primary['distance'] - reverse['distance']))
            if (not all(result['horizontal'] for result in (primary, strict, reverse))
                    or initial_discrepancy > DISTANCE_TOLERANCE):
                print('  tighter BFGS from original forward/reverse starting vectors', flush=True)
                refined = solve_fiber(args, seed, 5, 1e-11, 5000)
                refined_reverse = solve_fiber(reverse_args, seed + 2000, 3, 1e-11, 5000)
                forward_candidates.append(refined)
                reverse_candidates.append(refined_reverse)
            selected = min(forward_candidates, key=lambda result: result['horizontal_residual'])
            selected_reverse = min(reverse_candidates, key=lambda result: result['horizontal_residual'])
            discrepancy = abs(selected['distance'] - selected_reverse['distance'])
            # Strict agreement is checked against the refined forward solve when needed.
            if refined is None:
                discrepancy = max(discrepancy, abs(selected['distance'] - strict['distance']))
            approximation_start = perf_counter()
            approximation = d_0(*args)
            approximation_runtime = perf_counter() - approximation_start
            distance = selected['distance']
            exact = previous['d_f'] if previous['exact_error'] is not None else None
            exact_error = None if exact is None else abs(distance - exact)
            qualified = bool(selected['converged'] and selected_reverse['converged']
                             and selected['horizontal'] and selected_reverse['horizontal']
                             and discrepancy <= DISTANCE_TOLERANCE
                             and distance <= previous['diagonal_path_upper_bound'] + DISTANCE_TOLERANCE
                             and (exact_error is None or exact_error <= DISTANCE_TOLERANCE))
            summary = dict(case=previous['case'], description=previous['description'], n=previous['n'],
                           mean_norm=previous['mean_norm'], covariance_structure=previous['covariance_structure'],
                           d_f=distance, d_0=approximation, absolute_error=abs(approximation-distance),
                           relative_error=abs(approximation-distance)/distance,
                           horizontal_residual=selected['horizontal_residual'],
                           reverse_residual=selected_reverse['horizontal_residual'],
                           primary_residual=primary['horizontal_residual'], primary_distance=primary['distance'],
                           primary_converged=primary['converged'], final_converged=selected['converged'],
                           raw_primary_distance=primary['raw_distance'],
                           raw_primary_residual=primary['raw_horizontal_residual'],
                           raw_primary_spectrally_resolved=primary['raw_selection_spectrally_resolved'],
                           final_gtol=selected['gtol'], old_d_f=previous['d_f'],
                           old_distance_difference=abs(distance-previous['d_f']),
                           validation_discrepancy=discrepancy, exact_error=exact_error,
                           qualified=qualified, runtime_d_f=selected['runtime'],
                           runtime_primary=primary['runtime'], runtime_d_0=approximation_runtime,
                           runtime_all_solves=sum(result['runtime'] for result in forward_candidates + reverse_candidates))
            record = dict(summary=summary, **{key:previous[key] for key in
                          ('mu0','mu1','covariance0','covariance1','construction','normalized_condition','normalized_mean_norm')},
                          primary=primary, strict=strict, reverse=reverse, refined=refined,
                          refined_reverse=refined_reverse, gradient_check=directional_gradient_check(args, seed),
                          runtime_case=perf_counter()-case_start)
            records.append(record)
            save_results(records, metadata)
            print(f"  dF={distance:.10f} d0={approximation:.10f} error={100*summary['relative_error']:.5f}% "
                  f"residual={selected['horizontal_residual']:.3g} qualified={qualified}", flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--summarize', action='store_true', help='Screen saved runs and regenerate reports without optimizing.')
    if parser.parse_args().summarize:
        refresh_saved_results()
    else:
        main()
