"""Compare Euclidean-parameter MDM with numerical Fisher MDM on fixed simulations.

Run from the repository root: python experiments/compare_mdm.py
Each observation is a Gaussian descriptor, not a raw sample from that Gaussian.
No test-set tuning or selection of favorable seeds is performed.
"""

import argparse
import csv
import json
from pathlib import Path
import platform
import sys
from time import perf_counter

import numpy as np
import scipy
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from fisher_rao import d_f_reference, exp_map_mvn, frechet_mean_mvn, log_map_mvn

FAMILIES = ('tight_fisher', 'broad_fisher', 'parameter_cloud', 'coupled_mixture')
LOG_OPTIONS = dict(n_starts=2, seed=1701, gtol=1e-11, maxiter=2000,
                   residual_tol=1e-8, endpoint_tol=1e-7)


def generate_sample(family: str, count: int, seed: int) -> dict:
    """Generate balanced Gaussian descriptors from a specified fixed family.

    Parameters
    ----------
    family : str
        One of FAMILIES; definitions are recorded in the generated report.
    count : int
        Observations per class, positive.
    seed : int
        Independent local random seed for this split.

    Returns
    -------
    dict
        Means, SPD covariances and binary labels in deterministic class order.
    """
    rng = np.random.default_rng(seed)
    means, covariances, labels = [], [], []
    centers = [np.array([-.6, -.2]), np.array([.6, .2])]
    rotation = np.array([[np.cos(.6), -np.sin(.6)], [np.sin(.6), np.cos(.6)]])
    center_covariances = [np.diag([.7, 1.6]), rotation @ np.diag([1.6, .7]) @ rotation.T]
    for label in range(2):
        if family in ('tight_fisher', 'broad_fisher'):
            values, vectors = np.linalg.eigh(center_covariances[label])
            root = (vectors * np.sqrt(values)) @ vectors.T
        for _ in range(count):
            if family == 'coupled_mixture':
                side = rng.choice([-1., 1.])
                mu = np.array([2 * side + (2 * label - 1) * .35 + .35 * rng.normal()])
                variance = (9. if side == (1 if label == 0 else -1) else 1.)
                C = np.array([[variance * np.exp(.25 * rng.normal())]])
            elif family == 'parameter_cloud':
                mu = centers[label] + .75 * rng.normal(size=2)
                # Bounded additive symmetric noise keeps lambda_min >= .7-.4.
                raw = rng.normal(size=(2, 2))
                perturbation = (raw + raw.T) / 2
                perturbation *= .4 * rng.random() / max(np.linalg.norm(perturbation, 2), 1e-15)
                C = center_covariances[label] + perturbation
            else:
                scale = .3 if family == 'tight_fisher' else .9
                a = scale * rng.normal(size=2)
                entries = scale * rng.normal(size=3)
                A = np.array([[np.sqrt(2) * entries[0], entries[2]],
                              [entries[2], np.sqrt(2) * entries[1]]])
                mu, C = exp_map_mvn(centers[label], center_covariances[label], root @ a, root @ A @ root)
            means.append(mu)
            covariances.append(C)
            labels.append(label)
    return dict(means=np.array(means), covariances=np.array(covariances), labels=np.array(labels))


def transform_sample(sample: dict) -> dict:
    """Apply the fixed invertible change of feature units to a 2D dataset.

    Parameters
    ----------
    sample : dict
        Two-dimensional Gaussian descriptors and labels.

    Returns
    -------
    dict
        The same descriptors transformed by B=diag(3,.3), b=(1,-2).
    """
    B, b = np.diag([3., .3]), np.array([1., -2.])
    return dict(means=sample['means'] @ B.T + b,
                covariances=B @ sample['covariances'] @ B.T,
                labels=sample['labels'].copy())


def distance_record(base: tuple, target: tuple) -> dict:
    """Compute a qualified numerical Fisher length and retain solver diagnostics.

    Parameters
    ----------
    base, target : tuple
        Gaussian parameters (mean, covariance).

    Returns
    -------
    dict
        Candidate distance, qualification, spectral checks and restart diagnostics.
        Failed solves are retained with a null distance.
    """
    try:
        result = log_map_mvn(*base, *target, **LOG_OPTIONS)
        return dict(distance=result.distance, reliable=result.reliable,
                    diagnostics=result.diagnostics, parameters=result.parameters,
                    runs=[dict(success=bool(run.success), message=str(run.message),
                               nit=int(run.get('nit', 0)), nfev=int(run.get('nfev', 0)),
                               diagnostics=run.get('diagnostics'),
                               qualification_error=run.get('qualification_error')) for run in result.runs])
    except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
        return dict(distance=None, reliable=False, error=str(error))


def evaluate_trial(family: str, seed: int, train: dict, test: dict) -> dict:
    """Fit both complete classifiers and score exactly the same held-out data.

    Parameters
    ----------
    family : str
        Simulation identifier, including a suffix for the scaling control.
    seed : int
        Replicate identifier.
    train, test : dict
        Independent splits, each with means, covariances and balanced labels.

    Returns
    -------
    dict
        Endpoints, prototypes, predictions, confusion matrices, timings and checks.
        Unqualified test predictions count as errors rather than being dropped.
    """
    fits, summaries = {}, {}
    for method in ('naive', 'fisher'):
        start = perf_counter()
        prototypes, fit_details = [], []
        for label in range(2):
            selected = train['labels'] == label
            means, covariances = train['means'][selected], train['covariances'][selected]
            initial = (means.mean(axis=0), covariances.mean(axis=0))
            if method == 'naive':
                prototypes.append(initial)
                fit_details.append(dict(converged=True))
            else:
                try:
                    result = frechet_mean_mvn(means, covariances, init=initial,
                                              max_iter=60, tol=1e-6, log_options=LOG_OPTIONS)
                    prototypes.append((result.mean, result.covariance))
                    fit_details.append(dict(converged=result.converged, message=result.message,
                                            history=result.history))
                except (RuntimeError, ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                    prototypes.append(None)
                    fit_details.append(dict(converged=False, error=str(error)))
        train_seconds = perf_counter() - start
        start = perf_counter()
        distances = np.full((len(test['labels']), 2), np.nan)
        qualified = np.zeros_like(distances, dtype=bool)
        records = []
        for index, target in enumerate(zip(test['means'], test['covariances'])):
            row = []
            for label, prototype in enumerate(prototypes):
                if prototype is None:
                    row.append(dict(reliable=False, error='Prototype fit failed.'))
                elif method == 'naive':
                    distances[index, label] = np.sqrt(np.sum((target[0] - prototype[0])**2)
                                                       + np.sum((target[1] - prototype[1])**2))
                    qualified[index, label] = True
                else:
                    record = distance_record(prototype, target)
                    row.append(record)
                    if record['distance'] is not None:
                        distances[index, label] = record['distance']
                    qualified[index, label] = record['reliable']
            if row:
                records.append(row)
        predict_seconds = perf_counter() - start
        valid = qualified.all(axis=1)
        predictions = np.full(len(valid), -1)
        predictions[valid] = np.argmin(distances[valid], axis=1)
        confusion = np.zeros((2, 3), dtype=int)
        np.add.at(confusion, (test['labels'], np.where(predictions == -1, 2, predictions)), 1)
        summary = dict(accuracy=float(np.mean(predictions == test['labels'])),
                       prediction_coverage=float(valid.mean()),
                       all_fits_converged=all(item['converged'] for item in fit_details),
                       train_seconds=train_seconds, predict_seconds=predict_seconds,
                       confusion=confusion)
        summaries[method] = summary
        fits[method] = dict(prototypes=prototypes, fit_details=fit_details,
                            predictions=predictions, distances=distances, distance_records=records, **summary)
    # Independently check one test-to-prototype distance per class using reduced J.
    validation = []
    for label, prototype in enumerate(fits['fisher']['prototypes']):
        if prototype is not None:
            index = int(np.flatnonzero(test['labels'] == label)[0])
            target = (test['means'][index], test['covariances'][index])
            try:
                reference = d_f_reference(*prototype, *target, n_starts=3, gtol=1e-6)
                validation.append(dict(reference_reliable=reference.reliable,
                                       difference=abs(reference.distance - fits['fisher']['distances'][index, label])))
            except (ValueError, FloatingPointError, np.linalg.LinAlgError) as error:
                validation.append(dict(reference_reliable=False, error=str(error)))
    return dict(family=family, seed=seed, train=train, test=test, methods=fits,
                independent_distance_checks=validation,
                accuracy_difference=summaries['fisher']['accuracy'] - summaries['naive']['accuracy'])


def json_default(value: object) -> object:
    """Convert NumPy values for durable JSON output.

    Parameters
    ----------
    value : object
        NumPy array or scalar encountered by the JSON encoder.

    Returns
    -------
    object
        Native list or scalar.

    Raises
    ------
    TypeError
        If the value has an unsupported type.
    """
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(str(type(value)))


def save_report(records: list[dict], metadata: dict, output: Path) -> None:
    """Save all trials, a compact CSV and an unfiltered descriptive summary.

    Parameters
    ----------
    records : list of dict
        Completed trials including failures.
    metadata : dict
        Fixed design, solver settings and execution environment.
    output : Path
        Output prefix; its parent is created if needed.
    """
    output.parent.mkdir(parents=True, exist_ok=True)
    output.with_suffix('.json').write_text(json.dumps(dict(metadata=metadata, trials=records),
                                                     default=json_default, indent=2) + '\n', encoding='utf-8')
    rows = []
    for record in records:
        for method, data in record['methods'].items():
            rows.append(dict(family=record['family'], seed=record['seed'], method=method,
                             **{key: data[key] for key in ('accuracy', 'prediction_coverage', 'all_fits_converged',
                                                          'train_seconds', 'predict_seconds')}))
    with output.with_suffix('.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = ['# Synthetic Gaussian MDM comparison', '',
             'Numerical observations, not a claim of universal classification superiority.', '',
             'Naive: separate arithmetic means and sqrt(||delta_mu||² + ||delta_Sigma||_F²). '
             'Fisher: estimated Frechet prototypes and qualified horizontal-geodesic lengths. '
             'Both use identical held-out samples. Each descriptor is an exact Gaussian; '
             'finite-sample estimation of descriptors is not simulated.', '',
             f"Planned design: {metadata['repeats']} independent seeds, {metadata['train_per_class']} train and "
             f"{metadata['test_per_class']} test descriptors per class; two balanced classes. "
             'Reported standard deviations are across replicate accuracies (ddof=1), not confidence intervals.', '',
             '| Family | Trials | Naive accuracy (mean ± SD) | Fisher accuracy (mean ± SD) | Paired gain (pp ± SD) | Qualified Fisher trials |',
             '|---|---:|---:|---:|---:|---:|']
    for family in dict.fromkeys(record['family'] for record in records):
        subset = [record for record in records if record['family'] == family]
        naive = 100 * np.array([record['methods']['naive']['accuracy'] for record in subset])
        fisher = 100 * np.array([record['methods']['fisher']['accuracy'] for record in subset])
        ddof = 1 if len(subset) > 1 else 0
        qualified = sum(record['methods']['fisher']['all_fits_converged'] and
                        record['methods']['fisher']['prediction_coverage'] == 1 for record in subset)
        lines.append(f'| {family} | {len(subset)} | {naive.mean():.2f} ± {naive.std(ddof=ddof):.2f}% | '
                     f'{fisher.mean():.2f} ± {fisher.std(ddof=ddof):.2f}% | '
                     f'{(fisher-naive).mean():+.2f} ± {(fisher-naive).std(ddof=ddof):.2f} | {qualified}/{len(subset)} |')
    lines += ['', '## Fixed generators', '',
              '- `tight_fisher` / `broad_fisher`: 2D tangent-normal samples mapped by the Fisher exponential '
              'around m0=(-.6,-.2), C0=diag(.7,1.6), m1=(.6,.2), '
              'C1=R(.6)diag(1.6,.7)R(.6). Normalized tangent components are independent normal: '
              'a_j~N(0,s²), A_jj~N(0,2s²), A_12~N(0,s²), s=.3 or .9. '
              'This construction is favorable in principle to intrinsic geometry; it is not an unbiased model of real data.',
              '- `parameter_cloud`: same 2D centers; means have additive N(0,.75² I) noise; '
              'covariance noise is a random symmetric matrix rescaled to spectral norm .4 U, U~Uniform(0,1). '
              'This provides a contrasting parameter-space construction.',
              '- `coupled_mixture`: 1D deliberately multimodal classes. Equiprobable side z=±1; '
              'mu=2z+.35(2c-1)+.35 epsilon. Variance is 9 exp(.25 eta) if z=1-2c, '
              'otherwise exp(.25 eta); epsilon and eta are independent standard normals. '
              'One prototype per class need not represent these mixtures well.',
              '- `broad_fisher_scaled`: exactly the same broad samples, transformed by '
              'B=diag(3,.3), b=(1,-2). Both classifiers are refitted, without tuning their settings.', '',
              'All seeds and outputs are retained, without selection on accuracy. Training and test RNG seeds '
              'are separate. No test observations are used to fit or choose prototypes. '
              'Ties go to class 0 for both methods. Accuracy equals balanced accuracy because classes have equal sizes.', '',
              'Unqualified predictions are marked -1 and counted as errors. Nonconverged prototype fits '
              'are flagged even if a last iterate can be classified. Qualified-trial counts require both '
              'converged fits and full prediction coverage. The JSON retains every distance qualification '
              'and restart termination, mean history, endpoint, prototype and prediction. '
              'The minimizing-horizontal-geodesic assumption remains explicit; no global mean is certified.', '',
              '## Feature-scale check', '']
    for scaled in (record for record in records if record['family'] == 'broad_fisher_scaled'):
        original = next(record for record in records if record['family'] == 'broad_fisher' and record['seed'] == scaled['seed'])
        changes = {method: int(np.sum(scaled['methods'][method]['predictions'] != original['methods'][method]['predictions']))
                   for method in ('naive', 'fisher')}
        lines.append(f"- Seed {scaled['seed']}: changed predictions naive={changes['naive']}, Fisher={changes['fisher']}.")
    lines += ['', '## Runtime and independent checks', '']
    for method in ('naive', 'fisher'):
        lines.append(f"- {method}: total training {sum(r['methods'][method]['train_seconds'] for r in records):.3f} s; "
                     f"total prediction {sum(r['methods'][method]['predict_seconds'] for r in records):.3f} s (one BLAS thread).")
    checks = [check for record in records for check in record['independent_distance_checks']]
    differences = [check['difference'] for check in checks if check.get('reference_reliable')]
    lines.append(f'- Independent reduced-objective checks qualified: {len(differences)}/{len(checks)}; '
                 f'maximum length discrepancy: {max(differences, default=float("nan")):.3g}.')
    output.with_suffix('.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


def main() -> None:
    """Run the fixed benchmark with checkpointed reproducible outputs."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repeats', type=int, default=5)
    parser.add_argument('--train', type=int, default=12)
    parser.add_argument('--test', type=int, default=40)
    parser.add_argument('--output', type=Path, default=ROOT / 'results' / 'mdm_comparison')
    args = parser.parse_args()
    if min(args.repeats, args.train, args.test) < 1:
        parser.error('Counts must be positive.')
    metadata = dict(repeats=args.repeats, train_per_class=args.train, test_per_class=args.test,
                    python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
                    log_options=LOG_OPTIONS, mean_options=dict(max_iter=60, tol=1e-6, init='arithmetic'),
                    seeds=[20261015 + 100 * index for index in range(args.repeats)],
                    split_seeds='train=replicate seed, test=replicate seed+1', blas_threads=1)
    records = []
    with threadpool_limits(limits=1):
        for family in FAMILIES:
            for seed in metadata['seeds']:
                train, test = generate_sample(family, args.train, seed), generate_sample(family, args.test, seed + 1)
                variants = [(family, train, test)]
                if family == 'broad_fisher':
                    variants.append((family + '_scaled', transform_sample(train), transform_sample(test)))
                for name, training, testing in variants:
                    print(f'{name} seed={seed}: fitting and classifying', flush=True)
                    record = evaluate_trial(name, seed, training, testing)
                    records.append(record)
                    save_report(records, metadata, args.output)
                    print('  ' + ' '.join(f"{method}={data['accuracy']:.3f} "
                                          f"fit_ok={data['all_fits_converged']} coverage={data['prediction_coverage']:.3f}"
                                          for method, data in record['methods'].items()), flush=True)


if __name__ == '__main__':
    main()
