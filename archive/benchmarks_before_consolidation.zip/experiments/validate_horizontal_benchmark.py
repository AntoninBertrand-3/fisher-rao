"""Validate stored horizontal solutions without rerunning their optimizations."""

import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from scipy.linalg import eigvalsh, logm, solve, svd
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from fisher_rao import normalize_pair
from fisher_rao.horizontality import HorizontalFiberObjective


def independent_exact_distance(record: dict) -> float | None:
    """Evaluate exact metric formulas for the three saved sanity-check cases.

    Parameters
    ----------
    record : dict
        Saved Gaussian endpoints and case description.

    Returns
    -------
    float or None
        Exact special-case distance, or None outside these cases.
    """
    case = record['summary']['case']
    mean0, mean1 = np.asarray(record['mu0']), np.asarray(record['mu1'])
    covariance0, covariance1 = np.asarray(record['covariance0']), np.asarray(record['covariance1'])
    if case == 'P01':
        sigma0, sigma1 = np.sqrt(covariance0[0, 0]), np.sqrt(covariance1[0, 0])
        argument = ((mean1[0]-mean0[0])**2 + 2*(sigma0**2+sigma1**2)) / (4*sigma0*sigma1)
        return float(np.sqrt(2) * np.arccosh(argument))
    if case == 'P02':
        return float(np.linalg.norm(np.log(eigvalsh(covariance1, covariance0))) / np.sqrt(2))
    if case == 'P03':
        delta = mean1 - mean0
        mahalanobis_squared = delta @ solve(covariance0, delta, assume_a='pos')
        return float(np.sqrt(2) * np.arccosh(1 + mahalanobis_squared / 4))
    return None


def main() -> None:
    """Check exact inputs, restart vectors, independent spectra and gradients."""
    source = ROOT / 'results' / 'mixed_presentation_cases.json'
    benchmark_path = ROOT / 'results' / 'horizontal_presentation_cases.json'
    source_bytes = source.read_bytes()
    previous = json.loads(source_bytes)
    benchmark = json.loads(benchmark_path.read_text(encoding='utf-8'))
    assert len(benchmark['cases']) == len(previous) == 14
    assert benchmark['metadata']['source_sha256'] == hashlib.sha256(source_bytes).hexdigest()
    checks = []
    with threadpool_limits(limits=1):
        for record, old in zip(benchmark['cases'], previous, strict=True):
            summary = record['summary']
            assert summary['case'] == old['case']
            for key in ('mu0', 'mu1', 'covariance0', 'covariance1'):
                np.testing.assert_array_equal(record[key], old[key])
            args = tuple(np.asarray(record[key]) for key in ('mu0', 'covariance0', 'mu1', 'covariance1'))
            objective = HorizontalFiberObjective(*normalize_pair(*args))
            for stage in ('primary', 'strict', 'reverse', 'refined', 'refined_reverse'):
                result = record[stage]
                if result is None:
                    continue
                rng = np.random.default_rng(result['seed'])
                for index, run in enumerate(result['runs']):
                    expected = (np.zeros(objective.parameter_count) if index == 0
                                else rng.standard_normal(objective.parameter_count))
                    np.testing.assert_array_equal(run['initial_parameters'], expected)
            candidates = [record[stage] for stage in ('primary','strict','refined') if record[stage] is not None]
            selected = min(candidates, key=lambda result: result['horizontal_residual'])
            run = selected['runs'][selected['selected_index']]
            parameters = np.asarray(run['parameters'])
            factor = objective.factor(parameters)
            # A different LAPACK SVD driver provides a separate spectral check.
            left, singular, _ = svd(factor, full_matrices=False, lapack_driver='gesvd')
            logarithm = (left * (2*np.log(singular))) @ left.T
            independent_residual = float(np.linalg.norm(logarithm[:objective.n, objective.n+1:]))
            distance_difference = abs(float(np.linalg.norm(np.log(singular))) - summary['d_f'])
            exact = independent_exact_distance(record)
            exact_error = None if exact is None else abs(summary['d_f'] - exact)
            check = dict(case=summary['case'], identical_endpoints=True, identical_restart_vectors=True,
                         alternate_svd_distance_difference=distance_difference,
                         alternate_svd_residual=independent_residual,
                         exact_distance=exact, exact_absolute_error=exact_error,
                         d0_difference_from_old=abs(summary['d_0'] - old['d_0']),
                         initial_speed_difference=abs(summary['d_f'] - run['initial_fisher_speed']),
                         log_structure_error=run['log_structure_error'], lift_condition=run['lift_condition'])
            assert distance_difference < 1e-9
            assert independent_residual < 1e-7
            assert exact_error is None or exact_error < 1e-10
            assert check['d0_difference_from_old'] < 1e-10
            # Forming G loses precision when ill-conditioned; use a moderate cutoff.
            if run['lift_condition'] < 1e6:
                direct_log = logm(factor @ factor.T)
                check['direct_logm_difference'] = float(np.linalg.norm(direct_log - logarithm))
                assert check['direct_logm_difference'] < 1e-8
            gradient = record['gradient_check']
            if gradient['applicable']:
                best_error = min(step['absolute_error'] for step in gradient['steps'])
                check['gradient_best_absolute_error'] = best_error
                check['gradient_scaled_error'] = best_error / max(1., abs(gradient['analytic']))
                assert check['gradient_scaled_error'] < 1e-7
            checks.append(check)
    validation = dict(source_sha256=hashlib.sha256(source_bytes).hexdigest(), cases=checks,
                      all_checks_passed=True, qualified_count=sum(r['summary']['qualified'] for r in benchmark['cases']))
    (ROOT / 'results' / 'horizontal_validation.json').write_text(json.dumps(validation, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(cases=len(checks), all_checks_passed=True,
                         max_distance_difference=max(c['alternate_svd_distance_difference'] for c in checks),
                         max_horizontal_residual=max(c['alternate_svd_residual'] for c in checks),
                         max_gradient_scaled_error=max(c.get('gradient_scaled_error',0) for c in checks)), indent=2))


if __name__ == '__main__':
    main()
