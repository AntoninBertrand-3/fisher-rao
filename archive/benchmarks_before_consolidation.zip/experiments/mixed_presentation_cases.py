"""Compare a fixed mix of simple, diagonal and explicitly dense Gaussian pairs.

Run: python experiments/mixed_presentation_cases.py.
Retained rows are identified by their original P identifiers. New dense pairs
are fixed before evaluation, with independently generated covariance rotations.
"""

import csv
from dataclasses import dataclass
import json
from pathlib import Path
import platform
from time import perf_counter

import numpy as np
import scipy
from scipy.linalg import eigh

from presentation_cases import generate_cases as original_cases
from compare_d0_df import special_case_distance
from fisher_rao import d_0, d_f_reference, normalize_pair


@dataclass
class Pair:
    """Endpoint arrays, construction metadata and an optional exact distance."""

    name: str
    description: str
    mu: np.ndarray
    covariance0: np.ndarray
    covariance1: np.ndarray
    metadata: dict
    exact: float | None = None


def dense_covariance(generator: np.random.Generator, n: int, low: float, high: float) -> np.ndarray:
    """Construct a dense SPD covariance with a geometrically spaced spectrum.

    Parameters
    ----------
    generator : Generator
        Seeded random generator used for the Gaussian QR factorization.
    n : int
        Dimension.
    low, high : float
        Positive minimum and maximum covariance eigenvalues.

    Returns
    -------
    ndarray, shape (n, n)
        Symmetrized Q diag(geomspace(low, high, n)) Q.T.
    """
    basis, triangular = np.linalg.qr(generator.standard_normal((n, n)))
    basis *= np.where(np.diag(triangular) < 0, -1., 1.)
    covariance = (basis * np.geomspace(low, high, n)) @ basis.T
    return (covariance + covariance.T) / 2


def generate_pairs() -> list[Pair]:
    """Build fourteen fixed pairs, including seven new dense-covariance cases.

    Returns
    -------
    list of Pair
        Original coordinates with first endpoint mean zero in every case.
    """
    previous = original_cases()
    pairs = []
    for index in (0, 1, 2, 6, 7, 13):
        label, case = previous[index]
        pairs.append(Pair(case.case_id, label, case.mu, np.eye(case.dimension), case.covariance,
                          dict(source="original presentation suite", seed=case.seed,
                               covariance_structure="diagonal"), special_case_distance(case)))
    pairs.append(Pair("D01", "Explicit dense covariance", np.array([2., -1.]), np.eye(2),
                      np.array([[2., 1.5], [1.5, 2.]]),
                      dict(covariance_structure="identity / dense", construction="explicit arrays")))
    # New draws, not common rotations of old pairs. In the last two rows,
    # each endpoint covariance receives its own independent QR eigenbasis.
    specifications = [
        ("D02", "Dense, mixed mean", 5, 10., (1., 1.), (.1, 10.)),
        ("D03", "Dense, large mean shift", 12, 30., (1., 1.), (.5, 2.)),
        ("D04", "Dense, strong anisotropy", 20, 20., (1., 1.), (.01, 100.)),
        ("D05", "Dense, dimension 30", 30, 10., (1., 1.), (.5, 2.)),
        ("D06", "Two dense, noncommuting", 5, 10., (.5, 2.), (.1, 10.)),
        ("D07", "Two dense, noncommuting", 20, 20., (.2, 5.), (.05, 20.)),
    ]
    for index, (name, label, n, norm, spectrum0, spectrum1) in enumerate(specifications):
        seed = 20260930 + index
        generator = np.random.default_rng(seed)
        covariance0 = np.eye(n) if spectrum0 == (1., 1.) else dense_covariance(generator, n, *spectrum0)
        covariance1 = dense_covariance(generator, n, *spectrum1)
        direction = generator.standard_normal(n)
        mu = norm * (direction / np.linalg.norm(direction))
        pairs.append(Pair(name, label, mu, covariance0, covariance1,
                          dict(seed=seed, spectrum0=spectrum0, spectrum1=spectrum1,
                               mean_norm=norm, covariance_structure="identity / dense" if spectrum0 == (1., 1.) else "dense / dense",
                               draw_order="QR for Sigma0 if nonidentity; QR for Sigma1; Gaussian mean direction")))
    label, case = previous[14]
    pairs.append(Pair(case.case_id, label, case.mu, np.eye(2), case.covariance,
                      dict(source="original presentation suite", covariance_structure="diagonal", seed=case.seed)))
    return pairs


def diagnostics(result) -> dict:
    """Serialize all restart diagnostics without changing termination flags.

    Parameters
    ----------
    result : ReferenceResult
        Numerical reference result.

    Returns
    -------
    dict
        Selected distance, reliability and every restart's diagnostics.
    """
    return dict(distance=result.distance, reliable=result.reliable, message=result.reliability_message,
                parameters=result.parameters.tolist(), runs=[
                    dict(success=bool(run.success), objective=float(run.fun),
                         gradient_norm=float(np.linalg.norm(run.jac)), message=str(run.message),
                         nit=int(run.nit), nfev=int(run.nfev)) for run in result.runs])


def evaluate(pair: Pair) -> tuple[dict, dict]:
    """Evaluate distances and check restart, reversal and diagonal-path agreement.

    Parameters
    ----------
    pair : Pair
        Fixed Gaussian endpoints with first mean zero.

    Returns
    -------
    row, record : dict
        Compact results and complete endpoints with numerical diagnostics.
    """
    n = pair.mu.size
    seed = pair.metadata.get("seed", 20260929)
    args = (np.zeros(n), pair.covariance0, pair.mu, pair.covariance1)
    start = perf_counter()
    approximation = d_0(*args)
    runtime0 = perf_counter() - start
    start = perf_counter()
    reference = d_f_reference(*args, n_starts=5, seed=seed, gtol=1e-6, maxiter=2000)
    runtimef = perf_counter() - start
    strict = d_f_reference(*args, n_starts=2, seed=seed + 1000, gtol=1e-8, maxiter=2000)
    reverse = d_f_reference(pair.mu, pair.covariance1, np.zeros(n), pair.covariance0,
                            n_starts=3, seed=seed + 2000, gtol=1e-6, maxiter=2000)
    mean, covariance = normalize_pair(*args)
    eigenvalues, basis = eigh(covariance)
    eigen_mean = basis.T @ mean
    sigma = np.sqrt(eigenvalues)
    # Product of univariate hyperbolic distances: a path upper bound, not d_F.
    difference = (eigenvalues - 1) / (sigma + 1)
    angles = np.arcsinh(np.hypot(eigen_mean, np.sqrt(2) * difference) / np.sqrt(8 * sigma))
    diagonal_bound = float(np.sqrt(8 * (angles @ angles)))
    discrepancy = max(abs(reference.distance - strict.distance), abs(reference.distance - reverse.distance))
    exact_error = None if pair.exact is None else abs(reference.distance - pair.exact)
    qualified = bool(reference.reliable and reverse.reliable and discrepancy < 1e-8
                     and reference.distance <= diagonal_bound + 1e-8
                     and (exact_error is None or exact_error < 1e-8))
    commutator = pair.covariance0 @ pair.covariance1 - pair.covariance1 @ pair.covariance0
    row = dict(case=pair.name, description=pair.description, n=n, mean_norm=float(np.linalg.norm(pair.mu)),
               normalized_mean_norm=float(np.linalg.norm(mean)), normalized_condition=float(eigenvalues[-1] / eigenvalues[0]),
               covariance_structure=pair.metadata["covariance_structure"], d_f=reference.distance, d_0=approximation,
               absolute_error=abs(approximation - reference.distance),
               relative_error=abs(approximation - reference.distance) / reference.distance,
               runtime_d_f=runtimef, runtime_d_0=runtime0, validation_discrepancy=discrepancy,
               diagonal_path_upper_bound=diagonal_bound, exact_error=exact_error, qualified=qualified,
               commutator_norm=float(np.linalg.norm(commutator)))
    record = dict(**row, mu0=np.zeros(n).tolist(), mu1=pair.mu.tolist(),
                  covariance0=pair.covariance0.tolist(), covariance1=pair.covariance1.tolist(),
                  construction=pair.metadata, optimizer="BFGS", seed=seed, maxiter=2000,
                  primary_settings=dict(n_starts=5, gtol=1e-6),
                  strict_settings=dict(n_starts=2, gtol=1e-8, seed=seed + 1000),
                  reverse_settings=dict(n_starts=3, gtol=1e-6, seed=seed + 2000),
                  primary=diagnostics(reference), strict=diagnostics(strict), reverse=diagnostics(reverse),
                  python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__)
    return row, record


def main() -> None:
    """Save the new table, all endpoints and diagnostics without replacing old results."""
    output = Path(__file__).resolve().parents[1] / "results"
    rows, records = [], []
    for pair in generate_pairs():
        row, record = evaluate(pair)
        rows.append(row)
        records.append(record)
        (output / "mixed_presentation_cases.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
        print(f"{pair.name} n={row['n']} dF={row['d_f']:.8f} d0={row['d_0']:.8f} "
              f"error={100 * row['relative_error']:.5f}% qualified={row['qualified']} "
              f"check_delta={row['validation_discrepancy']:.2g}", flush=True)
    with (output / "mixed_presentation_cases.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = ["# Mixed diagonal and dense covariance comparison", "",
             "All first means are zero. Mean norm denotes ||mu1|| in the original coordinates. "
             "The condition number is that of Sigma0^(-1/2) Sigma1 Sigma0^(-1/2). "
             "P identifiers retain old cases; D identifiers denote new cases fixed before evaluation.", "",
             "| Case | Configuration | n | Mean norm | Covariance structure | d_F numerical | d_0 | Relative error |",
             "|---|---|---:|---:|---|---:|---:|---:|"]
    for row in rows:
        lines.append(f"| {row['case']} | {row['description']} | {row['n']} | {row['mean_norm']:.4g} | "
                     f"{row['covariance_structure']} | {row['d_f']:.6f} | {row['d_0']:.6f} | {100*row['relative_error']:.4f}% |")
    lines += ["", "## Precise constructions", "",
              "P01, P02, P03, P07, P08, P14 and P15 retain the endpoints of presentation_endpoints.json. "
              "Every actual endpoint in the new table is also stored at full precision in mixed_presentation_cases.json.", "",
              "D01: mu1=(2,-1), Sigma0=I2, Sigma1=[[2,1.5],[1.5,2]].", "",
              "For D02-D07, use numpy.random.default_rng(seed). Each dense covariance is Q diag(geomspace(a,b,n)) Q.T, "
              "where Q is the QR basis of a fresh standard-normal n by n matrix, with QR diagonal signs made positive. "
              "Generate Sigma0 if nonidentity, then Sigma1, then z=standard_normal(n) and mu1=r*z/||z||. "
              "The two dense endpoint covariances use independent bases, not a common rotation of an old pair.", "",
              "| Case | Seed | Spectrum Sigma0 | Spectrum Sigma1 | r |", "|---|---:|---|---|---:|",
              "| D02 | 20260930 | [1,1] | [0.1,10] | 10 |",
              "| D03 | 20260931 | [1,1] | [0.5,2] | 30 |",
              "| D04 | 20260932 | [1,1] | [0.01,100] | 20 |",
              "| D05 | 20260933 | [1,1] | [0.5,2] | 10 |",
              "| D06 | 20260934 | [0.5,2] | [0.1,10] | 10 |",
              "| D07 | 20260935 | [0.2,5] | [0.05,20] | 20 |", "",
              "## Numerical checks", "",
              "The primary reference uses five-start analytic-gradient BFGS, gtol=1e-6, maxiter=2000. "
              "Checks use two strict starts at gtol=1e-8, three reversed-endpoint starts at gtol=1e-6, "
              "available exact cases, and the diagonal-path upper bound after normalization. "
              "Precision-loss diagnostics of strict solves are preserved. A qualified row requires converged "
              "primary and reverse results and distance agreement within 1e-8.", "",
              f"Qualified cases: {sum(r['qualified'] for r in rows)}/{len(rows)}. "
              f"Maximum strict/reverse discrepancy: {max(r['validation_discrepancy'] for r in rows):.3g}.", "",
              "These checks establish numerical consistency, not certified global minima or a proof of the reduced "
              "Fisher-distance identity. Zero displayed errors mean agreement at displayed precision. "
              "P15 remains as an explicit stress case; no new case was removed based on its result."]
    (output / "mixed_presentation_cases.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
