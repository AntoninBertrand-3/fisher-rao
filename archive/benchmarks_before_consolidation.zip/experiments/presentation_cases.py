"""Run a fixed, compact comparison suite and regenerate its presentation table.

Run from the repository root: python experiments/presentation_cases.py.
All pairs start at N(0,I); covariance ranges are variances, not standard deviations.
Cases are fixed before evaluation, with no selection based on observed errors.
"""

import csv
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy.optimize import minimize_scalar

import compare_d0_df as benchmark
from compare_d0_df import Case, evaluate_case
from fisher_rao import d_0, d_f_reference, skew_from_parameters, skew_objective


def generate_cases() -> list[tuple[str, Case]]:
    """Construct simple, mixed-direction, high-dimensional and stress cases.

    Returns
    -------
    list of tuple
        Descriptions and normalized endpoints, with reproducible construction data.
    """
    specifications = [
        ("Univariate", 1, 4., 4., 3., "random"),
        ("Covariance only", 3, .1, 10., 0., "random"),
        ("Mean only, large shift", 5, 1., 1., 20., "random"),
        ("Isotropic expansion", 5, 25., 25., 10., "random"),
        ("Isotropic contraction", 5, .04, .04, 10., "random"),
        ("Anisotropic, aligned mean", 5, .1, 10., 10., "max_eigenvector"),
        ("Anisotropic, mixed mean", 5, .1, 10., 10., "random"),
        ("Strong anisotropy, mixed mean", 5, .01, 100., 20., "random"),
        ("Moderate spectrum", 12, .5, 2., 3., "random"),
        ("Large mean shift", 12, .5, 2., 30., "random"),
        ("Anisotropic, mixed mean", 20, .1, 10., 10., "random"),
        ("Strong anisotropy, mixed mean", 20, .01, 100., 20., "random"),
        ("Moderate spectrum", 30, .5, 2., 10., "random"),
        ("Anisotropic, large mean shift", 30, .1, 10., 30., "random"),
        ("Stress family, L=100", 2, .01, 100., np.sqrt(101.), "stress"),
        ("Stress family, L=1000", 2, .001, 1000., np.sqrt(1001.), "stress"),
    ]
    cases = []
    for index, (label, n, low, high, norm, orientation) in enumerate(specifications):
        seed = 20260910 + index
        generator = np.random.default_rng(seed)
        eigenvalues = np.geomspace(low, high, n)
        # Diagonal representatives make spectra and mean orientation transparent.
        # Orthogonal rotation leaves both distances unchanged.
        direction = generator.standard_normal(n)
        direction /= np.linalg.norm(direction)
        if orientation == "max_eigenvector":
            direction = np.eye(n)[-1]
        elif orientation == "stress":
            direction = np.array([1., np.sqrt(high)]) / norm
        family = "identity" if low == high == 1 else "isotropic" if low == high else "diagonal"
        case = Case(f"P{index + 1:02d}", n, family, high, norm, orientation,
                    seed, norm * direction, np.diag(eigenvalues), eigenvalues)
        cases.append((label, case))
    return cases


def write_table(rows: list[dict[str, object]], output: Path) -> None:
    """Render the saved numerical results as a Markdown table.

    Parameters
    ----------
    rows : list of dict
        Evaluated cases including reverse-endpoint validation.
    output : Path
        Markdown output file.
    """
    lines = [
        "# Compact comparison of d_0 and the numerical d_F reference", "",
        "All pairs are N(0,I) versus N(mu,Sigma). Spectral ranges refer to covariance eigenvalues. "
        "Relative error is 100 |d_0-d_F|/d_F. The 16 cases were fixed before evaluation; no cases were removed.", "",
        "| Case | Configuration | n | Mean norm | Spectrum | d_F (numerical) | d_0 | Relative error |",
        "|---|---|---:|---:|---|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(f"| {row['case_id']} | {row['description']} | {row['dimension']} | "
                     f"{row['mu_norm']:.4g} | [{row['lambda_min']:g}, {row['lambda_max']:g}] | "
                     f"{row['d_f_reference']:.6f} | {row['d_0']:.6f} | {100 * row['relative_error']:.4f}% |")
    lines += ["", "## Reference qualification", "",
              "The reference minimizes the repository's canonical J(K) using analytic-gradient BFGS "
              "with five starts (zero plus four seeded Gaussian starts), gtol=1e-8 and maxiter=2000. "
              "Three further starts solve each pair with reversed endpoints. Convergence and agreement "
              "are numerical checks, not a certificate of global optimality or an independent proof of the reduced identity.", "",
              f"Forward converged references: {sum(r['reference_reliable'] for r in rows)}/{len(rows)}. "
              f"Reverse converged references: {sum(r['reverse_reliable'] for r in rows)}/{len(rows)}. "
              f"Maximum forward/reverse distance discrepancy: {max(r['reverse_difference'] for r in rows):.3g}.", "",
              "When strict BFGS reports precision loss, an additional five-start solve uses gtol=1e-6. "
              "A reference is qualified only when that solve converges and agrees with the strict result "
              "within 1e-9 in distance, and endpoint reversal agrees within 1e-9. The strict results "
              "and diagnostics are retained, including unsuccessful terminations.", "",
              f"References passing these numerical checks: {sum(r['presentation_qualified'] for r in rows)}/{len(rows)}. "
              f"Maximum tolerance-check discrepancy: {max(r['tolerance_check_difference'] for r in rows):.3g}.", "",
              "Covariances are diagonal representatives: generic mixed means still require full skew optimization. "
              "A common invertible affine transformation produces equivalent pairs with noncommuting covariances. "
              "The last two rows explicitly probe the historical anisotropic stress family mu=(1,sqrt(L)), "
              "Sigma=diag(1/L,L). They are not representative random samples.", "",
              "Full endpoints, seeds, timings, solver settings and restart diagnostics are in presentation_cases.csv. "
              "Historical asymptotic claims are not assumed in interpreting these results.", "",
              "The companion presentation_validation.json records a separate Brent scalar optimization "
              "of each 2D stress case and an affine-invariance check of P08 with noncommuting endpoint covariances. "
              "These checks use the same reduced objective, not an independent Fisher geodesic solver. "
              "Displayed zero errors mean agreement at the displayed precision."]
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")


def additional_checks(rows: list[dict[str, object]], output: Path) -> None:
    """Check scalar optimization and a noncommuting affine representative.

    Parameters
    ----------
    rows : list of dict
        Fixed-suite reference distances and approximations.
    output : Path
        JSON destination for independent numerical check diagnostics.
    """
    cases = generate_cases()
    checks = {}
    for index in (14, 15):
        case = cases[index][1]

        def scalar_objective(coordinate: float) -> float:
            """Evaluate the two-dimensional skew objective.

            Parameters
            ----------
            coordinate : float
                Single upper-triangle skew entry.

            Returns
            -------
            float
                Canonical squared-distance objective.
            """
            return skew_objective(case.mu, case.covariance, skew_from_parameters([coordinate], 2))

        result = minimize_scalar(scalar_objective, method="brent", bracket=(0., 1.),
                                 options={"xtol": 1e-11, "maxiter": 1000})
        checks[case.case_id] = dict(method="Brent scalar minimization", success=bool(result.success),
                                   distance=float(np.sqrt(result.fun)), coordinate=float(result.x),
                                   distance_difference=abs(float(np.sqrt(result.fun)) - rows[index]["d_f_reference"]))
    case = cases[7][1]
    generator = np.random.default_rng(20260910)
    orthogonal, _ = np.linalg.qr(generator.standard_normal((5, 5)))
    transform = np.diag(np.linspace(.5, 2., 5)) @ orthogonal
    shift = generator.standard_normal(5)
    covariance0 = transform @ transform.T
    covariance1 = transform @ case.covariance @ transform.T
    args = (shift, covariance0, transform @ case.mu + shift, covariance1)
    reference = d_f_reference(*args, n_starts=5, seed=case.seed, gtol=1e-6, maxiter=2000)
    checks["affine_P08"] = dict(seed=20260910, transform=transform.tolist(), shift=shift.tolist(),
                               covariance_commutator_norm=float(np.linalg.norm(covariance0 @ covariance1 - covariance1 @ covariance0)),
                               reliable=reference.reliable, gtol=1e-6, n_starts=5, solver_seed=case.seed,
                               d0_difference=abs(d_0(*args) - rows[7]["d_0"]),
                               df_difference=abs(reference.distance - rows[7]["d_f_reference"]))
    output.write_text(json.dumps(checks, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    """Evaluate every fixed case and save results incrementally for reproducibility."""
    benchmark.N_STARTS = 5
    benchmark.MAXITER = 2000
    output = Path(__file__).resolve().parents[1] / "results"
    output.mkdir(exist_ok=True)
    rows = []
    with (output / "presentation_cases.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = None
        for label, case in generate_cases():
            start = perf_counter()
            row = evaluate_case(case)
            reverse = d_f_reference(case.mu, case.covariance, np.zeros(case.dimension),
                                    np.eye(case.dimension), n_starts=3, seed=case.seed + 10000,
                                    gtol=benchmark.GTOL, maxiter=benchmark.MAXITER)
            row.update(description=label, lambda_min=case.eigenvalues.min(),
                       lambda_max=case.eigenvalues.max(), reverse_distance=reverse.distance,
                       reverse_reliable=reverse.reliable,
                       reverse_difference=abs(reverse.distance - row["d_f_reference"]),
                       reverse_diagnostics_json=json.dumps([
                           dict(success=bool(run.success), objective=float(run.fun),
                                gradient_norm=float(np.linalg.norm(run.jac)), message=str(run.message),
                                nit=int(run.nit), nfev=int(run.nfev)) for run in reverse.runs]))
            check = None
            if not row["reference_reliable"] or not reverse.reliable:
                check = d_f_reference(np.zeros(case.dimension), np.eye(case.dimension),
                                      case.mu, case.covariance, n_starts=5, seed=case.seed,
                                      gtol=1e-6, maxiter=benchmark.MAXITER)
            difference = 0. if check is None else abs(check.distance - row["d_f_reference"])
            row.update(tolerance_check_gtol=1e-6, tolerance_check_difference=difference,
                       tolerance_check_reliable=True if check is None else check.reliable,
                       tolerance_check_diagnostics_json=json.dumps([] if check is None else [
                           dict(success=bool(run.success), objective=float(run.fun),
                                gradient_norm=float(np.linalg.norm(run.jac)), message=str(run.message),
                                nit=int(run.nit), nfev=int(run.nfev)) for run in check.runs]),
                       presentation_qualified=bool((row["reference_reliable"] if check is None else check.reliable)
                                                   and difference < 1e-9 and row["reverse_difference"] < 1e-9
                                                   and row["exact_check_pass"] is not False))
            if writer is None:
                writer = csv.DictWriter(stream, fieldnames=list(row))
                writer.writeheader()
            writer.writerow(row)
            stream.flush()
            rows.append(row)
            print(f"{case.case_id} n={case.dimension:2} {label}: "
                  f"dF={row['d_f_reference']:.8f} d0={row['d_0']:.8f} "
                  f"error={100 * row['relative_error']:.5f}% "
                  f"reliable={row['reference_reliable']}/{reverse.reliable} "
                  f"qualified={row['presentation_qualified']} "
                  f"reverse_delta={row['reverse_difference']:.2g} time={perf_counter()-start:.1f}s", flush=True)
    write_table(rows, output / "presentation_cases.md")
    additional_checks(rows, output / "presentation_validation.json")


if __name__ == "__main__":
    main()
