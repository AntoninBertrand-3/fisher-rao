# MDM on Gaussian descriptors estimated from 3D Gaussian samples

Numerical observations on a fixed synthetic design, not a general performance guarantee.

Each class has one fixed 3D parent Gaussian. A datapoint is an MVN fitted to a fresh independent batch of raw samples from that parent. No raw observations are shared between datapoints or training and test splits. Mean estimation uses the sample average; covariance uses denominator m-1, without shrinkage or regularization.

Design: 5 seeds, 12 train and 40 test descriptors per class per trial; two balanced classes. Naive MDM uses separate arithmetic prototypes and Euclidean parameter distance sqrt(||delta_mu||²+||delta_Sigma||_F²). Fisher MDM uses estimated Frechet prototypes and qualified horizontal-geodesic lengths. Neither uses test data to fit prototypes.

| Separation s | Raw samples per descriptor | Trials | Naive accuracy ± SD | Fisher accuracy ± SD | Paired gain (pp ± SD) | Qualified Fisher trials |
|---|---:|---:|---:|---:|---:|---:|
| 0.35 | 10 | 5 | 67.75 ± 7.88% | 75.50 ± 9.21% | +7.75 ± 3.47 | 5/5 |
| 0.35 | 30 | 5 | 76.75 ± 9.59% | 86.75 ± 2.09% | +10.00 ± 8.71 | 5/5 |
| 0.35 | 100 | 5 | 94.75 ± 3.47% | 98.50 ± 1.05% | +3.75 ± 3.64 | 5/5 |
| 0.8 | 10 | 5 | 87.50 ± 4.24% | 95.50 ± 3.60% | +8.00 ± 1.90 | 5/5 |
| 0.8 | 30 | 5 | 98.00 ± 1.68% | 100.00 ± 0.00% | +2.00 ± 1.68 | 5/5 |
| 0.8 | 100 | 5 | 100.00 ± 0.00% | 100.00 ± 0.00% | +0.00 ± 0.00 | 5/5 |

SD means standard deviation across replicate accuracies, not a confidence interval. No seed was selected or dropped based on its performance. Accuracy is also balanced accuracy.

## Parent laws and reproducibility

C0=diag(1,.6,1.8), Q=sqrt(C0), v=(.8,-.5,.6). Class 0 is N(0,C0); class 1 is N(s*v, Q exp(s*B) Q), with

```text
B = [[ .7, .35, -.2],
     [.35, -.6, .25],
     [-.2, .25,  .2]]
```

Thus both means and covariances differ, and parent covariances do not commute. s=.35 and .8 are the two fixed separation settings; m=10,30,100 are the fixed raw batch sizes. Larger m reduces descriptor estimation noise; it does not increase the number of training descriptors.

Exact parent matrices, descriptor arrays, seeds, predictions and all mean/distance diagnostics are in the companion JSON. Raw draws are reproducible using the recorded NumPy version and seeds. The train seed is the replicate seed; test uses seed+1. Different settings reuse seed numbers as a common-random-number design, so settings are not independent experiments.

Prototype initialization is the arithmetic prototype. The existing fixed solver settings are unchanged from compare_mdm.py: 60 mean iterations, Fisher gradient tolerance 1e-6, two fiber starts, gtol=1e-11, horizontal tolerance 1e-8, endpoint tolerance 1e-7. Unqualified predictions count as errors; fit nonconvergence is explicitly flagged. Qualification is numerical and assumes that recovered horizontal geodesics minimize length; it does not prove global optimality.

## Numerical checks and cost

- Independent reduced-distance spot checks: 60/60 qualified; maximum discrepancy 5.11e-14.
- naive: total training 0.004 s; total prediction 0.116 s (one BLAS thread).
- fisher: total training 60.110 s; total prediction 86.739 s (one BLAS thread).

Reproduce:

```powershell
python experiments/compare_mdm_sampled.py
python experiments/plot_mdm_sampled.py
```
